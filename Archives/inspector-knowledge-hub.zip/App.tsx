import React, { useState } from 'react';
import { KnowledgeHub } from './components/KnowledgeHub';
import { AppContext, InspectionStage } from './types';
import { Camera, ClipboardCheck, LayoutDashboard, BrainCircuit, Info, MapPin } from 'lucide-react';

export default function App() {
  // State for the Knowledge Hub Panel
  const [isHubOpen, setIsHubOpen] = useState(false);

  // MOCK STATE: In a real app, this comes from your Router / Redux / Context
  const [appContext, setAppContext] = useState<AppContext>({
    userId: 'usr_123',
    tenantId: 'tenant_abc',
    currentScreen: 'dashboard',
    inspectionStage: InspectionStage.ENTRY,
    currentInspectionId: 'insp_888',
    currentJobId: 'job_999',
  });

  // Simulator helper to change context
  const setScreen = (screen: AppContext['currentScreen'], room?: string) => {
    setAppContext(prev => ({
      ...prev,
      currentScreen: screen,
      activeRoomType: room
    }));
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-900 flex">
      
      {/* Sidebar Navigation (Mock) */}
      <div className="w-16 md:w-64 bg-slate-900 text-white flex flex-col items-center md:items-start py-6 md:px-6 gap-6 hidden sm:flex">
        <div className="text-xl font-bold tracking-tight mb-4 hidden md:block text-blue-400">InspectOS</div>
        
        <NavButton 
          active={appContext.currentScreen === 'dashboard'} 
          icon={<LayoutDashboard size={20} />} 
          label="Dashboard" 
          onClick={() => setScreen('dashboard')} 
        />
        <NavButton 
          active={appContext.currentScreen === 'photo_upload'} 
          icon={<Camera size={20} />} 
          label="Inspection" 
          onClick={() => setScreen('photo_upload', 'Kitchen')} 
        />
        <NavButton 
          active={appContext.currentScreen === 'analysis_review'} 
          icon={<BrainCircuit size={20} />} 
          label="AI Review" 
          onClick={() => setScreen('analysis_review')} 
        />
        <NavButton 
          active={appContext.currentScreen === 'report_view'} 
          icon={<ClipboardCheck size={20} />} 
          label="Reports" 
          onClick={() => setScreen('report_view')} 
        />
      </div>

      {/* Main App Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        
        {/* Top Bar */}
        <header className="h-16 bg-white border-b flex items-center justify-between px-6 shadow-sm">
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-semibold capitalize text-slate-800">
               {appContext.currentScreen.replace('_', ' ')}
            </h1>
            {appContext.activeRoomType && (
                <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-medium flex items-center gap-1">
                    <MapPin size={12} /> {appContext.activeRoomType}
                </span>
            )}
          </div>

          <div className="flex items-center gap-4">
            {/* Knowledge Hub Trigger */}
            <button
              onClick={() => setIsHubOpen(true)}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full shadow-md hover:shadow-lg transition-all text-sm font-medium"
            >
              <Info size={18} />
              <span>Help & Guide</span>
            </button>
          </div>
        </header>

        {/* App Content Simulator */}
        <main className="flex-1 overflow-y-auto p-6 relative">
          
          {/* Simulation Controls - For Demo Purposes Only */}
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-8">
            <h3 className="text-orange-800 font-bold text-xs uppercase tracking-wide mb-2">Dev Context Simulator</h3>
            <p className="text-xs text-orange-700 mb-3">
              Change the state below to see how the Knowledge Hub recommendations change automatically.
            </p>
            <div className="flex flex-wrap gap-2">
              <SimButton active={appContext.currentScreen === 'photo_upload' && appContext.activeRoomType === 'Bathroom'} onClick={() => setScreen('photo_upload', 'Bathroom')} label="📸 Photo: Bathroom" />
              <SimButton active={appContext.currentScreen === 'photo_upload' && appContext.activeRoomType === 'Living Room'} onClick={() => setScreen('photo_upload', 'Living Room')} label="📸 Photo: Living Room" />
              <SimButton active={appContext.currentScreen === 'analysis_review'} onClick={() => setScreen('analysis_review')} label="🧠 AI Review Screen" />
              <SimButton active={appContext.currentScreen === 'report_view'} onClick={() => setScreen('report_view')} label="📄 Report Finalization" />
            </div>
          </div>

          {/* Dummy Content based on Screen */}
          <div className="max-w-4xl mx-auto">
            {appContext.currentScreen === 'dashboard' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-xl shadow-sm border h-48 flex items-center justify-center text-slate-400">Stats Widget</div>
                    <div className="bg-white p-6 rounded-xl shadow-sm border h-48 flex items-center justify-center text-slate-400">Recent Inspections</div>
                    <div className="bg-white p-6 rounded-xl shadow-sm border h-48 flex items-center justify-center text-slate-400">Team Activity</div>
                </div>
            )}

            {appContext.currentScreen === 'photo_upload' && (
                 <div className="bg-slate-800 rounded-2xl aspect-video flex items-center justify-center relative overflow-hidden shadow-lg">
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <div className="text-center">
                            <Camera size={48} className="text-white mx-auto mb-2 opacity-80" />
                            <p className="text-white font-medium">Camera Viewfinder ({appContext.activeRoomType})</p>
                        </div>
                    </div>
                    {/* Floating contextual hint inside the app itself */}
                    <div className="absolute bottom-6 left-6 right-6 bg-black/60 backdrop-blur-md p-4 rounded-lg border border-white/10 flex items-start gap-3">
                        <Info size={20} className="text-blue-400 shrink-0 mt-0.5" />
                        <div>
                            <p className="text-sm text-white font-medium">Photo Tip</p>
                            <p className="text-xs text-slate-200">
                                {appContext.activeRoomType === 'Bathroom' 
                                    ? "Don't forget to photograph under the sink and behind the toilet."
                                    : "Stand in the corner to get the widest angle of the room."}
                            </p>
                        </div>
                        <button onClick={() => setIsHubOpen(true)} className="ml-auto text-xs bg-white text-black px-3 py-1.5 rounded font-bold hover:bg-slate-200">
                            More Tips
                        </button>
                    </div>
                 </div>
            )}

             {appContext.currentScreen === 'analysis_review' && (
                 <div className="bg-white rounded-xl shadow border p-6">
                    <h2 className="text-lg font-bold mb-4">AI Findings Review</h2>
                    <div className="space-y-4">
                        <div className="border rounded-lg p-4 flex gap-4 items-start bg-red-50 border-red-100">
                            <div className="w-20 h-20 bg-slate-200 rounded-md"></div>
                            <div>
                                <div className="flex gap-2 items-center mb-1">
                                    <span className="font-bold text-red-700">Major Damage Detected</span>
                                    <span className="text-xs bg-red-200 text-red-800 px-1.5 py-0.5 rounded">94% Confidence</span>
                                </div>
                                <p className="text-sm text-slate-600 mb-2">Wall impact damage detected in Hallway.</p>
                                <div className="flex gap-2">
                                    <button className="text-xs bg-white border px-3 py-1 rounded shadow-sm">Confirm</button>
                                    <button className="text-xs bg-white border px-3 py-1 rounded shadow-sm text-red-600">Reject</button>
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
            )}
          </div>

        </main>
      </div>

      {/* The Actual Knowledge Hub Component */}
      <KnowledgeHub 
        isOpen={isHubOpen} 
        onClose={() => setIsHubOpen(false)} 
        context={appContext} 
      />

    </div>
  );
}

// UI Helpers
const NavButton = ({ active, icon, label, onClick }: any) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-3 w-full p-2 rounded-lg transition-all ${active ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
  >
    <div className="shrink-0">{icon}</div>
    <span className="hidden md:block font-medium text-sm">{label}</span>
  </button>
);

const SimButton = ({ active, label, onClick }: any) => (
    <button 
        onClick={onClick}
        className={`px-3 py-1.5 rounded-md text-xs font-semibold border transition-all ${active ? 'bg-orange-500 text-white border-orange-600' : 'bg-white text-slate-600 border-slate-300 hover:border-orange-400'}`}
    >
        {label}
    </button>
);