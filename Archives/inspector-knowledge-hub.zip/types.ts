// Domain Models matching the Firestore schema requirements

export enum ArticleCategory {
  GETTING_STARTED = 'getting_started',
  PHOTO_GUIDES = 'photo_guides',
  AI_GUIDES = 'ai_guides',
  STANDARDS = 'standards',
  TROUBLESHOOTING = 'troubleshooting',
  RELEASE_NOTES = 'release_notes',
}

export enum InspectionStage {
  ENTRY = 'entry',
  ROUTINE = 'routine',
  EXIT = 'exit',
  ALL = 'all',
}

export enum Audience {
  INSPECTOR = 'inspector',
  ADMIN = 'admin',
  ALL = 'all',
}

export interface KnowledgeArticle {
  articleId: string;
  title: string;
  summary: string;
  content: string; // Markdown or HTML string for this demo
  category: ArticleCategory;
  tags: string[];
  audience: Audience;
  inspectionStage?: InspectionStage;
  roomType?: string[]; // Array of room types this applies to
  createdAt: string;
  updatedAt: string;
  tenantId?: string | null; // null = global
}

export interface SupportRequest {
  requestId?: string;
  tenantId: string;
  userId: string;
  inspectionId?: string;
  jobId?: string;
  category: string;
  description: string;
  status: 'open' | 'in_progress' | 'resolved';
  createdAt: string;
}

// App Context Types for the Simulator
export type ScreenContext = 'dashboard' | 'photo_upload' | 'analysis_review' | 'report_view';

export interface AppContext {
  userId: string;
  tenantId: string;
  currentScreen: ScreenContext;
  currentInspectionId?: string;
  currentJobId?: string;
  inspectionStage: InspectionStage;
  activeRoomType?: string; // e.g., "Kitchen", "Bathroom"
}