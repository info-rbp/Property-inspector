import { ArticleCategory, Audience, InspectionStage, KnowledgeArticle } from './types';

// Simulating a database of articles
export const MOCK_ARTICLES: KnowledgeArticle[] = [
  {
    articleId: '1',
    title: 'Complete your first inspection in 10 minutes',
    summary: 'A quick start guide to navigating the app and finishing your first job.',
    content: `
      # Getting Started
      
      Welcome to the platform. Here is how you can finish your first inspection quickly:
      
      1. **Select a Property**: Choose from your daily list.
      2. **Start Inspection**: Tap the green start button.
      3. **Walkthrough**: Move room by room.
      
      **Tip**: Always start from the front door and work clockwise.
    `,
    category: ArticleCategory.GETTING_STARTED,
    tags: ['onboarding', 'tutorial', 'basics'],
    audience: Audience.INSPECTOR,
    inspectionStage: InspectionStage.ALL,
    createdAt: '2023-10-01T10:00:00Z',
    updatedAt: '2023-10-01T10:00:00Z',
  },
  {
    articleId: '2',
    title: 'How to photograph walls properly',
    summary: 'Ensure AI accuracy by taking clean, well-lit photos of walls.',
    content: `
      # Wall Photography Standards
      
      Bad photos lead to bad AI results. Follow these rules:
      
      *   **Stand back**: Get the whole wall in one shot if possible.
      *   **Avoid Glare**: Do not shoot directly into a window or mirror.
      *   **Level Camera**: Keep your phone parallel to the wall.
      
      ## What Good Looks Like
      Even lighting, clear corners, no blur.
      
      ## What Bad Looks Like
      Dark shadows, angled shots, reflection of the inspector in mirrors.
    `,
    category: ArticleCategory.PHOTO_GUIDES,
    tags: ['photos', 'walls', 'ai-accuracy'],
    audience: Audience.INSPECTOR,
    inspectionStage: InspectionStage.ALL,
    roomType: ['Living Room', 'Bedroom', 'Kitchen', 'Hallway'],
    createdAt: '2023-10-05T12:00:00Z',
    updatedAt: '2023-10-05T12:00:00Z',
  },
  {
    articleId: '3',
    title: 'Bathroom photo checklist',
    summary: 'Specific requirements for wet areas and plumbing fixtures.',
    content: `
      # Bathroom Checklist
      
      Bathrooms are high-risk areas. Ensure you capture:
      
      1. Under the sink (piping).
      2. Inside the shower recess (grout condition).
      3. The toilet seal.
      4. The ceiling (for mold).
    `,
    category: ArticleCategory.PHOTO_GUIDES,
    tags: ['photos', 'bathroom', 'plumbing'],
    audience: Audience.INSPECTOR,
    inspectionStage: InspectionStage.ALL,
    roomType: ['Bathroom', 'Ensuite', 'Laundry'],
    createdAt: '2023-10-06T09:30:00Z',
    updatedAt: '2023-10-06T09:30:00Z',
  },
  {
    articleId: '4',
    title: 'What AI confidence means',
    summary: 'Understanding the confidence score and when to intervene.',
    content: `
      # AI Confidence Scores
      
      The AI assigns a score (0-100%) to every defect it finds.
      
      *   **High (90%+)**: The AI is very sure. Verify quickly.
      *   **Medium (50-89%)**: Check closely. The AI might be seeing a shadow.
      *   **Low (<50%)**: Needs human confirmation.
      
      **Important**: You are the expert. If the AI is wrong, reject the finding.
    `,
    category: ArticleCategory.AI_GUIDES,
    tags: ['ai', 'confidence', 'trust'],
    audience: Audience.ALL,
    inspectionStage: InspectionStage.ALL,
    createdAt: '2023-11-01T14:00:00Z',
    updatedAt: '2023-11-01T14:00:00Z',
  },
  {
    articleId: '5',
    title: 'Difference between wear and damage',
    summary: 'Legal definitions to use in your reports.',
    content: `
      # Wear vs. Damage
      
      *   **Fair Wear & Tear**: Natural deterioration over time (e.g., faded curtains, traffic marks on carpet).
      *   **Damage**: Caused by accident, negligence, or malice (e.g., red wine stain, fist hole in wall).
      
      **Do not** use the word "Damage" unless you are certain it is not wear.
    `,
    category: ArticleCategory.STANDARDS,
    tags: ['legal', 'definitions', 'reporting'],
    audience: Audience.INSPECTOR,
    inspectionStage: InspectionStage.EXIT,
    createdAt: '2023-09-15T08:00:00Z',
    updatedAt: '2023-09-15T08:00:00Z',
  },
  {
    articleId: '6',
    title: 'AI flagged damage I don’t agree with',
    summary: 'How to override the AI without breaking the report.',
    content: `
      # Disagreeing with AI
      
      1. Tap the defect card.
      2. Select "Reject Finding".
      3. Select a reason (e.g., "It's a shadow", "It's dirt, not damage").
      
      This trains the model for next time.
    `,
    category: ArticleCategory.TROUBLESHOOTING,
    tags: ['ai', 'override', 'correction'],
    audience: Audience.INSPECTOR,
    inspectionStage: InspectionStage.ALL,
    createdAt: '2023-12-01T11:00:00Z',
    updatedAt: '2023-12-01T11:00:00Z',
  },
    {
    articleId: '7',
    title: 'Entry vs Exit inspections',
    summary: 'Key differences in what you need to capture.',
    content: `
      # Entry vs Exit
      
      **Entry**: Document the pristine condition. Every scratch needs to be noted to protect the tenant.
      
      **Exit**: Focus on changes since the Entry report. Compare side-by-side.
    `,
    category: ArticleCategory.GETTING_STARTED,
    tags: ['process', 'entry', 'exit'],
    audience: Audience.INSPECTOR,
    inspectionStage: InspectionStage.ENTRY,
    createdAt: '2023-12-01T11:00:00Z',
    updatedAt: '2023-12-01T11:00:00Z',
  }
];

export const CATEGORY_LABELS: Record<ArticleCategory, string> = {
  [ArticleCategory.GETTING_STARTED]: 'Getting Started',
  [ArticleCategory.PHOTO_GUIDES]: 'Photo Standards',
  [ArticleCategory.AI_GUIDES]: 'AI Assistance',
  [ArticleCategory.STANDARDS]: 'Inspection Standards',
  [ArticleCategory.TROUBLESHOOTING]: 'Troubleshooting',
  [ArticleCategory.RELEASE_NOTES]: 'Release Notes',
};