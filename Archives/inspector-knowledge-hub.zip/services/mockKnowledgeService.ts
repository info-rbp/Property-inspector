import { MOCK_ARTICLES } from '../constants';
import { AppContext, KnowledgeArticle, SupportRequest } from '../types';

// Simulate API latency
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const knowledgeService = {
  /**
   * GET /v1/knowledge/search?q=
   * Full-text search simulation
   */
  async searchArticles(query: string): Promise<KnowledgeArticle[]> {
    await delay(300); // Network latency
    const q = query.toLowerCase();
    
    if (!q) return [];

    return MOCK_ARTICLES.filter((article) => {
      // Basic scoring weight logic (simulated)
      const inTitle = article.title.toLowerCase().includes(q);
      const inTags = article.tags.some(tag => tag.toLowerCase().includes(q));
      const inSummary = article.summary.toLowerCase().includes(q);
      
      return inTitle || inTags || inSummary;
    });
  },

  /**
   * GET /v1/knowledge/contextual
   * Returns recommended articles based on App Context
   */
  async getContextualSuggestions(context: AppContext): Promise<KnowledgeArticle[]> {
    await delay(300);

    return MOCK_ARTICLES.filter((article) => {
      let score = 0;

      // Filter by Inspection Stage (if article specifies one)
      if (article.inspectionStage && article.inspectionStage !== 'all' && article.inspectionStage !== context.inspectionStage) {
        return false;
      }

      // Boost by Room Type
      if (context.activeRoomType && article.roomType?.includes(context.activeRoomType)) {
        score += 10;
      }

      // Boost by Category based on Screen
      if (context.currentScreen === 'photo_upload' && article.category === 'photo_guides') {
        score += 5;
      }
      if (context.currentScreen === 'analysis_review' && article.category === 'ai_guides') {
        score += 5;
      }
      if (context.currentScreen === 'report_view' && article.category === 'standards') {
        score += 5;
      }

      return score > 0;
    }).sort((a, b) => {
        // Sort explicitly for demo stability
        return a.title.localeCompare(b.title);
    });
  },

  /**
   * GET /v1/knowledge/articles/{id}
   */
  async getArticleById(id: string): Promise<KnowledgeArticle | undefined> {
    await delay(200);
    return MOCK_ARTICLES.find(a => a.articleId === id);
  },

  /**
   * POST /v1/support/requests
   */
  async submitSupportRequest(request: Partial<SupportRequest>): Promise<{ success: boolean; id: string }> {
    await delay(800);
    // In a real app, this would POST to Cloud Run / Firestore
    console.log('Support Ticket Created:', request);
    return { success: true, id: `req_${Math.floor(Math.random() * 10000)}` };
  }
};