import React from 'react';
import { KnowledgeArticle } from '../types';
import { CATEGORY_LABELS } from '../constants';
import { ArrowLeft, Tag } from 'lucide-react';

interface ArticleViewProps {
  article: KnowledgeArticle;
  onBack: () => void;
}

export const ArticleView: React.FC<ArticleViewProps> = ({ article, onBack }) => {
  return (
    <div className="flex flex-col h-full bg-white animate-in slide-in-from-right duration-300">
      <div className="sticky top-0 z-10 bg-white border-b px-4 py-3 flex items-center gap-3">
        <button 
          onClick={onBack}
          className="p-1 hover:bg-slate-100 rounded-full transition-colors text-slate-600"
          aria-label="Back"
        >
          <ArrowLeft size={20} />
        </button>
        <div>
           <p className="text-xs font-medium text-blue-600 uppercase tracking-wide">
            {CATEGORY_LABELS[article.category]}
          </p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5 hub-scroll">
        <h1 className="text-2xl font-bold text-slate-900 mb-2">{article.title}</h1>
        
        <div className="flex flex-wrap gap-2 mb-6">
          {article.tags.map(tag => (
            <span key={tag} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-slate-100 text-slate-600">
              <Tag size={10} className="mr-1" />
              {tag}
            </span>
          ))}
        </div>

        {/* Mock Markdown Rendering - In production use react-markdown */}
        <div className="prose prose-sm prose-slate max-w-none">
          {article.content.split('\n').map((line, idx) => {
            if (line.trim().startsWith('# ')) {
              return <h2 key={idx} className="text-xl font-bold mt-6 mb-2">{line.replace('# ', '')}</h2>;
            }
            if (line.trim().startsWith('## ')) {
              return <h3 key={idx} className="text-lg font-semibold mt-4 mb-2">{line.replace('## ', '')}</h3>;
            }
            if (line.trim().startsWith('* ')) {
              return (
                <li key={idx} className="ml-4 list-disc text-slate-700 my-1">
                  {line.replace('* ', '').split('**').map((part, i) => 
                    i % 2 === 1 ? <strong key={i}>{part}</strong> : part
                  )}
                </li>
              );
            }
             if (line.trim().startsWith('1. ')) {
              return (
                <div key={idx} className="ml-4 text-slate-700 my-1 font-medium">
                  {line}
                </div>
              );
            }
            if (line.trim() === '') return <div key={idx} className="h-2" />;
            
            return <p key={idx} className="text-slate-700 my-2 leading-relaxed">
               {line.split('**').map((part, i) => 
                    i % 2 === 1 ? <strong key={i}>{part}</strong> : part
                  )}
            </p>;
          })}
        </div>

        <div className="mt-10 pt-6 border-t border-slate-200">
          <p className="text-xs text-slate-400 text-center">
            Did this answer help? <button className="text-blue-600 underline">Yes</button> • <button className="text-blue-600 underline">No</button>
          </p>
        </div>
      </div>
    </div>
  );
};