import React, { useState } from 'react';
import { AppContext } from '../types';
import { knowledgeService } from '../services/mockKnowledgeService';
import { AlertCircle, CheckCircle2, Loader2, Send } from 'lucide-react';

interface SupportFormProps {
  context: AppContext;
  onCancel: () => void;
}

export const SupportForm: React.FC<SupportFormProps> = ({ context, onCancel }) => {
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('general');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    setIsSubmitting(true);

    try {
      await knowledgeService.submitSupportRequest({
        tenantId: context.tenantId,
        userId: context.userId,
        inspectionId: context.currentInspectionId,
        jobId: context.currentJobId,
        category,
        description,
        status: 'open',
      });
      setIsSuccess(true);
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center animate-in fade-in">
        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-4">
          <CheckCircle2 size={32} />
        </div>
        <h3 className="text-lg font-bold text-slate-900 mb-2">Request Sent</h3>
        <p className="text-sm text-slate-600 mb-6">
          Our support team has received your ticket. We'll email you shortly.
        </p>
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-slate-100 text-slate-700 font-medium rounded-lg hover:bg-slate-200 transition-colors"
        >
          Return to App
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b bg-slate-50">
        <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
          <AlertCircle size={20} className="text-orange-500" />
          Contact Support
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          We'll attach your current inspection details automatically.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex-1 p-4 flex flex-col gap-4 overflow-y-auto">
        {/* Context Badge */}
        <div className="bg-blue-50 border border-blue-100 rounded-md p-3 text-xs text-blue-800">
          <span className="font-semibold block mb-1">Attached Context:</span>
          Inspection ID: {context.currentInspectionId || 'N/A'}<br/>
          Stage: {context.inspectionStage}
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Issue Type
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full rounded-lg border-slate-300 border bg-white px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          >
            <option value="general">General Question</option>
            <option value="app_issue">App Not Working</option>
            <option value="photo_upload">Photo Upload Issue</option>
            <option value="ai_dispute">AI Analysis Dispute</option>
            <option value="report_generation">Report Generation</option>
          </select>
        </div>

        <div className="flex-1">
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Description
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what happened..."
            className="w-full h-full min-h-[120px] rounded-lg border-slate-300 border bg-white px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
            required
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting || !description}
          className="w-full mt-auto bg-blue-600 text-white font-medium py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {isSubmitting ? (
            <>
              <Loader2 size={18} className="animate-spin" /> Sending...
            </>
          ) : (
            <>
              Send Request <Send size={18} />
            </>
          )}
        </button>
        
        <button
            type="button"
            onClick={onCancel}
            className="w-full text-slate-500 text-sm py-2 hover:text-slate-800"
        >
            Cancel
        </button>
      </form>
    </div>
  );
};