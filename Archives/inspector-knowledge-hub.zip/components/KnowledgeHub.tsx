import React, { useState, useEffect } from 'react';
import { Search, X, BookOpen, ChevronRight, LifeBuoy, FileText } from 'lucide-react';
import { AppContext, KnowledgeArticle } from '../types';
import { knowledgeService } from '../services/mockKnowledgeService';
import { ArticleView } from './ArticleView';
import { SupportForm } from './SupportForm';

interface KnowledgeHubProps {
  isOpen: boolean;
  onClose: () => void;
  context: AppContext;
}

type ViewState = 'home' | 'article' | 'support' | 'search_results';

export const KnowledgeHub: React.FC<KnowledgeHubProps> = ({ isOpen, onClose, context }) => {
  const [view, setView] = useState<ViewState>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<KnowledgeArticle[]>([]);
  const [searchResults, setSearchResults] = useState<KnowledgeArticle[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<KnowledgeArticle | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load contextual suggestions when the panel opens or context changes
  useEffect(() => {
    if (isOpen && view === 'home') {
      setIsLoading(true);
      knowledgeService.getContextualSuggestions(context).then(data => {
        setSuggestions(data);
        setIsLoading(false);
      });
    }
  }, [isOpen, context, view]);

  // Handle search
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsLoading(true);
    setView('search_results');
    const results = await knowledgeService.searchArticles(searchQuery);
    setSearchResults(results);
    setIsLoading(false);
  };

  const openArticle = (article: KnowledgeArticle) => {
    setSelectedArticle(article);
    setView('article');
  };

  const goHome = () => {
    setView('home');
    setSearchQuery('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[400px] bg-white shadow-2xl z-50 transform transition-transform duration-300 border-l border-slate-200 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b bg-white flex items-center justify-between shadow-sm z-20">
        <h2 className="font-bold text-slate-800 flex items-center gap-2 text-lg">
          <BookOpen size={20} className="text-blue-600" />
          Knowledge Hub
        </h2>
        <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full">
          <X size={20} />
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden relative bg-slate-50">
        
        {view === 'article' && selectedArticle ? (
          <ArticleView article={selectedArticle} onBack={() => setView(searchResults.length > 0 ? 'search_results' : 'home')} />
        ) : view === 'support' ? (
          <SupportForm context={context} onCancel={goHome} />
        ) : (
          <div className="flex flex-col h-full">
            {/* Search Bar */}
            <div className="p-4 bg-white border-b">
              <form onSubmit={handleSearch} className="relative">
                <Search size={16} className="absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="How do I..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-100 text-slate-800 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 focus:bg-white border-transparent focus:border-blue-200 transition-all outline-none"
                />
              </form>
            </div>

            {/* Content List */}
            <div className="flex-1 overflow-y-auto p-4 hub-scroll">
              {isLoading ? (
                <div className="flex flex-col gap-4 mt-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="h-24 bg-slate-200 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : view === 'search_results' ? (
                <div>
                   <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">
                      Search Results ({searchResults.length})
                    </h3>
                    <button onClick={goHome} className="text-xs text-blue-600 font-medium hover:underline">Clear Search</button>
                   </div>
                   
                   {searchResults.length === 0 ? (
                     <div className="text-center py-10 text-slate-500">
                       <p>No results found.</p>
                       <button onClick={() => setView('support')} className="text-blue-600 font-medium mt-2 hover:underline">Contact Support</button>
                     </div>
                   ) : (
                     <div className="flex flex-col gap-3">
                        {searchResults.map(article => (
                          <ArticleCard key={article.articleId} article={article} onClick={() => openArticle(article)} />
                        ))}
                     </div>
                   )}
                </div>
              ) : (
                <div>
                  {/* Contextual Suggestions */}
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                        Recommended for you
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full font-medium border border-blue-200">
                         {context.activeRoomType || context.currentScreen.replace('_', ' ')}
                      </span>
                    </div>
                    
                    {suggestions.length > 0 ? (
                      <div className="flex flex-col gap-3">
                        {suggestions.map(article => (
                          <ArticleCard key={article.articleId} article={article} onClick={() => openArticle(article)} />
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-slate-500 italic">No specific recommendations for this screen.</p>
                    )}
                  </div>

                  {/* Categories / Standard Links */}
                  <div className="border-t border-slate-200 pt-6">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                      Browse Help
                    </h3>
                    <div className="grid grid-cols-2 gap-3">
                      <CategoryButton label="Getting Started" onClick={() => { setSearchQuery('Getting Started'); handleSearch({preventDefault: () => {}} as any)}} />
                      <CategoryButton label="Photo Guide" onClick={() => { setSearchQuery('Photo'); handleSearch({preventDefault: () => {}} as any)}} />
                      <CategoryButton label="AI Help" onClick={() => { setSearchQuery('AI'); handleSearch({preventDefault: () => {}} as any)}} />
                      <CategoryButton label="Standards" onClick={() => { setSearchQuery('Standards'); handleSearch({preventDefault: () => {}} as any)}} />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Support CTA */}
            <div className="p-4 border-t bg-white">
              <button
                onClick={() => setView('support')}
                className="w-full flex items-center justify-center gap-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-medium py-2.5 rounded-lg transition-colors shadow-sm"
              >
                <LifeBuoy size={18} />
                Still stuck? Contact Support
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Sub-components for list items
const ArticleCard: React.FC<{ article: KnowledgeArticle; onClick: () => void }> = ({ article, onClick }) => (
  <div 
    onClick={onClick}
    className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all cursor-pointer group"
  >
    <div className="flex justify-between items-start">
      <h4 className="font-semibold text-slate-800 text-sm group-hover:text-blue-600 transition-colors">
        {article.title}
      </h4>
      <ChevronRight size={16} className="text-slate-300 group-hover:text-blue-500" />
    </div>
    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
      {article.summary}
    </p>
    <div className="flex gap-2 mt-2">
        {article.tags.slice(0, 2).map(t => (
            <span key={t} className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded">#{t}</span>
        ))}
    </div>
  </div>
);

const CategoryButton: React.FC<{ label: string; onClick: () => void }> = ({ label, onClick }) => (
  <button 
    onClick={onClick}
    className="bg-white border border-slate-200 p-3 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50 hover:border-slate-300 hover:text-blue-600 transition-all text-left flex items-center gap-2"
  >
    <FileText size={16} className="text-slate-400" />
    {label}
  </button>
);