
import React, { useState } from 'react';
import { LayoutDashboard, Menu, X, ArrowRight, Settings as SettingsIcon, Building, Smartphone, Check } from 'lucide-react';
import ClientManager from './components/ClientManager';
import Settings from './components/Settings';
import RemoteManager from './components/RemoteManager';
import TenantInspection from './components/TenantInspection';
import { RemoteInspectionRequest, RemoteInspectionStatus, Property } from './types';
import { analyzeTenantPhotos } from './services/geminiService';

type ActiveTool = 'dashboard' | 'clients' | 'settings' | 'remote-inspections' | 'tenant-view-simulation' | 'manager-review';

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ActiveTool>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Central Database State
  const [properties, setProperties] = useState<Property[]>([]);
  const [remoteRequests, setRemoteRequests] = useState<RemoteInspectionRequest[]>([]);
  
  const [currentRequest, setCurrentRequest] = useState<RemoteInspectionRequest | null>(null);
  const [analyzingItems, setAnalyzingItems] = useState<Set<string>>(new Set());

  const handleCreateRemoteRequest = (req: RemoteInspectionRequest) => {
    setRemoteRequests(prev => [...prev, req]);
    setActiveTool('remote-inspections');
  };

  const handleTenantSubmit = (updatedReq: RemoteInspectionRequest) => {
      setRemoteRequests(prev => prev.map(r => r.id === updatedReq.id ? updatedReq : r));
      setActiveTool('remote-inspections');
      setCurrentRequest(null);
  };

  const handleLaunchTenantView = (req: RemoteInspectionRequest) => {
      setCurrentRequest(req);
      setActiveTool('tenant-view-simulation');
  };

  const handleReviewRequest = (req: RemoteInspectionRequest) => {
      setCurrentRequest(req);
      setActiveTool('manager-review');
      // Trigger Analysis automatically for items with photos
      runAIReview(req);
  };

  const runAIReview = async (req: RemoteInspectionRequest) => {
      // Deep clone to avoid direct mutation issues
      const updatedReq = JSON.parse(JSON.stringify(req)) as RemoteInspectionRequest;
      let hasUpdates = false;

      for (const room of updatedReq.data.rooms) {
          if (room.photos.length > 0) {
              for (const item of room.items) {
                  // Only analyze if not already done
                  if (!item.aiAnalysis) {
                       setAnalyzingItems(prev => new Set(prev).add(item.id));
                       try {
                           const result = await analyzeTenantPhotos(item.name, item.comment, room.photos);
                           item.aiAnalysis = result.text;
                           item.aiFlagged = result.isFlagged;
                           hasUpdates = true;
                           
                           // Progressive update
                           setRemoteRequests(prev => prev.map(r => r.id === req.id ? updatedReq : r));
                           setCurrentRequest(updatedReq);
                       } catch (e) {
                           console.error(e);
                       } finally {
                           setAnalyzingItems(prev => {
                               const next = new Set(prev);
                               next.delete(item.id);
                               return next;
                           });
                       }
                  }
              }
          }
      }
      
      if (hasUpdates) {
          setRemoteRequests(prev => prev.map(r => r.id === req.id ? updatedReq : r));
          setCurrentRequest(updatedReq);
      }
  };

  const ReviewInterface = () => {
    if (!currentRequest) return null;

    return (
        <div className="max-w-6xl mx-auto px-4 py-8 animate-in fade-in">
             <div className="flex justify-between items-center mb-6">
                 <div>
                     <button onClick={() => setActiveTool('remote-inspections')} className="text-gray-500 hover:text-gray-900 text-sm mb-2 flex items-center gap-1">
                         ← Back to List
                     </button>
                     <h1 className="text-2xl font-bold">Review: {currentRequest.propertyAddress}</h1>
                     <p className="text-gray-500">Tenant: {currentRequest.tenantName} • Submitted: {currentRequest.data.inspectionDate}</p>
                 </div>
                 <button 
                    onClick={() => {
                        const updated = { ...currentRequest, status: RemoteInspectionStatus.REVIEWED };
                        setRemoteRequests(prev => prev.map(r => r.id === currentRequest.id ? updated : r));
                        setActiveTool('remote-inspections');
                    }}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-green-700 flex items-center gap-2"
                 >
                     <Check size={20} /> Finalize & Approve
                 </button>
             </div>

             <div className="space-y-8">
                 {currentRequest.data.rooms.map(room => (
                     <div key={room.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                         <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                             <h3 className="font-bold text-lg text-gray-800">{room.name}</h3>
                         </div>
                         <div className="p-6">
                             {/* Photos Context */}
                             {room.photos.length > 0 && (
                                 <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
                                     {room.photos.map(p => (
                                         <div key={p.id} className="w-32 h-32 rounded-lg overflow-hidden flex-shrink-0 border border-gray-200">
                                             <img src={p.previewUrl} className="w-full h-full object-cover" />
                                         </div>
                                     ))}
                                 </div>
                             )}

                             <div className="space-y-4">
                                 {room.items.map(item => (
                                     <div key={item.id} className={`grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-lg border ${item.aiFlagged ? 'bg-red-50 border-red-200' : 'bg-white border-gray-100'}`}>
                                         {/* Tenant Side */}
                                         <div>
                                             <div className="flex items-center gap-2 mb-2">
                                                 <span className="font-bold text-gray-800">{item.name}</span>
                                                 <div className="flex gap-1">
                                                     {item.isClean && <span className="text-[10px] bg-green-100 text-green-800 px-1 rounded">Clean</span>}
                                                     {item.isUndamaged && <span className="text-[10px] bg-green-100 text-green-800 px-1 rounded">Undamaged</span>}
                                                     {item.isWorking && <span className="text-[10px] bg-green-100 text-green-800 px-1 rounded">Working</span>}
                                                 </div>
                                             </div>
                                             <p className="text-sm text-gray-600 bg-gray-50 p-2 rounded italic">
                                                 "{item.comment || 'No comment provided'}"
                                             </p>
                                         </div>

                                         {/* AI Side */}
                                         <div className="border-l pl-4 border-gray-200">
                                              <h4 className="text-xs font-bold text-gray-500 uppercase mb-2 flex items-center gap-2">
                                                  {analyzingItems.has(item.id) ? 'AI Analyzing...' : 'AI Risk Assessment'}
                                              </h4>
                                              {analyzingItems.has(item.id) ? (
                                                  <div className="h-12 w-full bg-gray-100 animate-pulse rounded"></div>
                                              ) : (
                                                  <p className={`text-sm ${item.aiFlagged ? 'text-red-700 font-medium' : 'text-green-700'}`}>
                                                      {item.aiAnalysis || 'Waiting for analysis...'}
                                                  </p>
                                              )}
                                         </div>
                                     </div>
                                 ))}
                             </div>
                         </div>
                     </div>
                 ))}
             </div>
        </div>
    );
  };

  const getActiveComponent = () => {
    switch (activeTool) {
      case 'clients':
        return <ClientManager properties={properties} setProperties={setProperties} />;
      case 'settings':
        return <Settings />;
      case 'remote-inspections':
        return <RemoteManager 
                  properties={properties}
                  requests={remoteRequests} 
                  onCreateRequest={handleCreateRemoteRequest} 
                  onLaunchTenantView={handleLaunchTenantView}
                  onReviewRequest={handleReviewRequest}
               />;
      case 'tenant-view-simulation':
        return currentRequest ? <TenantInspection request={currentRequest} onSubmit={handleTenantSubmit} /> : null;
      case 'manager-review':
        return <ReviewInterface />;
      default:
        return null;
    }
  };

  const NavButton = ({ tool, icon: Icon, label }: { tool: ActiveTool; icon: any; label: string }) => (
    <button 
      onClick={() => { setActiveTool(tool); setIsMobileMenuOpen(false); }}
      className={`text-sm font-medium transition-colors duration-200 flex items-center gap-2 px-3 py-2 rounded-lg ${
        activeTool === tool ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
      }`}
    >
      <Icon size={18} />
      {label}
    </button>
  );

  // Special case: Tenant View takes over the whole screen
  if (activeTool === 'tenant-view-simulation') {
      return (
          <div className="bg-gray-100 min-h-screen flex justify-center">
              <div className="w-full max-w-md bg-white shadow-2xl min-h-screen">
                  {currentRequest && <TenantInspection request={currentRequest} onSubmit={handleTenantSubmit} />}
              </div>
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans text-gray-900">
      
      {/* Top Navigation Bar */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTool('dashboard')}>
              <div className="w-9 h-9 bg-blue-800 rounded-lg text-white flex items-center justify-center font-bold text-lg shadow-sm">
                RB
              </div>
              <span className="font-bold text-xl text-gray-900 tracking-tight">Remote Business Partner</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              <NavButton tool="remote-inspections" icon={Smartphone} label="Remote Inspections" />
              <NavButton tool="clients" icon={Building} label="Property Manager" />
              <NavButton tool="settings" icon={SettingsIcon} label="Settings" />
            </nav>

            {/* Mobile Menu Toggle */}
            <div className="flex items-center gap-4 lg:hidden">
              <button 
                className="p-2 text-gray-600 rounded-lg hover:bg-gray-100"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-200 px-4 pt-2 pb-4 shadow-lg absolute w-full z-50">
             <div className="flex flex-col gap-2">
               <NavButton tool="dashboard" icon={LayoutDashboard} label="Dashboard" />
               <NavButton tool="remote-inspections" icon={Smartphone} label="Remote Inspections" />
               <NavButton tool="clients" icon={Building} label="Property Manager" />
               <NavButton tool="settings" icon={SettingsIcon} label="Settings" />
             </div>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTool === 'dashboard' ? (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-in fade-in slide-in-from-bottom-2 duration-500">
             
             <div className="mb-10 text-center md:text-left">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome Back, Admin</h1>
                <p className="text-gray-500">Overview of your remote inspection operations.</p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Featured Tool */}
                <div 
                  onClick={() => setActiveTool('remote-inspections')}
                  className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg border border-blue-500 p-6 hover:shadow-xl transition-all cursor-pointer group text-white relative overflow-hidden"
                >
                    <div className="absolute top-0 right-0 p-3 opacity-10">
                        <Smartphone size={120} />
                    </div>
                    <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-white/30 transition-colors backdrop-blur-sm">
                        <Smartphone size={28} />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Remote Inspections</h3>
                    <p className="text-blue-100 text-sm mb-6">
                        Send inspection links to tenants and let AI review their photos.
                    </p>
                    <div className="flex items-center text-white text-sm font-semibold group-hover:translate-x-1 transition-transform absolute bottom-6">
                        Manage Requests <ArrowRight size={16} className="ml-1" />
                    </div>
                </div>

                {/* Management Group */}
                <div 
                  onClick={() => setActiveTool('clients')}
                  className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md hover:border-purple-300 transition-all cursor-pointer group relative"
                >
                    <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-100 transition-colors">
                        <Building size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Property Manager</h3>
                    <p className="text-gray-500 text-sm mb-6">
                        Manage properties, owners, and tenant details.
                    </p>
                    <div className="flex items-center text-purple-600 text-sm font-semibold group-hover:translate-x-1 transition-transform absolute bottom-6">
                        View Properties <ArrowRight size={16} className="ml-1" />
                    </div>
                </div>

                <div 
                  onClick={() => setActiveTool('settings')}
                  className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md hover:border-gray-400 transition-all cursor-pointer group relative"
                >
                    <div className="w-12 h-12 bg-gray-100 text-gray-600 rounded-lg flex items-center justify-center mb-4 group-hover:bg-gray-200 transition-colors">
                        <SettingsIcon size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Settings</h3>
                    <p className="text-gray-500 text-sm mb-6">
                        Configure company profile and preferences.
                    </p>
                    <div className="flex items-center text-gray-700 text-sm font-semibold group-hover:translate-x-1 transition-transform absolute bottom-6">
                        Manage Settings <ArrowRight size={16} className="ml-1" />
                    </div>
                </div>

             </div>
          </div>
        ) : (
          getActiveComponent()
        )}
      </main>

    </div>
  );
};

export default App;
