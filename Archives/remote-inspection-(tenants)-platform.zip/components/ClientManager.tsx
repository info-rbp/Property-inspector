
import React, { useState } from 'react';
import { Users, Plus, Search, X, MapPin, Key, User, Phone, Mail, Building, Trash2, Edit, Home, Layers, LayoutTemplate } from 'lucide-react';
import { generateId } from '../utils';
import { Property } from '../types';

interface ClientManagerProps {
  properties: Property[];
  setProperties: React.Dispatch<React.SetStateAction<Property[]>>;
}

const ROOM_PRESETS = {
  'Studio': ['Entry', 'Living/Bedroom', 'Kitchen', 'Bathroom'],
  '1 Bed 1 Bath': ['Entry', 'Living Room', 'Kitchen', 'Bedroom', 'Bathroom', 'Laundry', 'Exterior'],
  '2 Bed 1 Bath': ['Entry', 'Living Room', 'Kitchen', 'Master Bedroom', 'Bedroom 2', 'Bathroom', 'Laundry', 'Exterior'],
  '3 Bed 2 Bath': ['Entry', 'Living Room', 'Kitchen', 'Master Bedroom', 'Ensuite', 'Bedroom 2', 'Bedroom 3', 'Main Bathroom', 'Laundry', 'Exterior', 'Garage'],
  '4 Bed 2 Bath': ['Entry', 'Living Room', 'Kitchen', 'Dining', 'Master Bedroom', 'Ensuite', 'Bedroom 2', 'Bedroom 3', 'Bedroom 4', 'Main Bathroom', 'Laundry', 'Alfresco', 'Garage', 'Exterior']
};

const ClientManager: React.FC<ClientManagerProps> = ({ properties, setProperties }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Room Management State within Modal
  const [currentRooms, setCurrentRooms] = useState<string[]>([]);
  const [newRoomInput, setNewRoomInput] = useState('');

  // Form State
  const [formData, setFormData] = useState<Omit<Property, 'id'>>({
    ownerName: '',
    ownerEmail: '',
    ownerPhone: '',
    address: '',
    managerType: 'Real Estate',
    keyDetails: 'Held with Agent',
    notes: '',
    tenantName: '',
    tenantEmail: '',
    defaultRooms: []
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const openAddModal = () => {
    setEditingId(null);
    setCurrentRooms(ROOM_PRESETS['2 Bed 1 Bath']); // Default starting point
    setFormData({
      ownerName: '',
      ownerEmail: '',
      ownerPhone: '',
      address: '',
      managerType: 'Real Estate',
      keyDetails: 'Held with Agent',
      notes: '',
      tenantName: '',
      tenantEmail: '',
      defaultRooms: []
    });
    setIsModalOpen(true);
  };

  const handleEdit = (property: Property, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setEditingId(property.id);
    setCurrentRooms(property.defaultRooms && property.defaultRooms.length > 0 ? property.defaultRooms : ROOM_PRESETS['2 Bed 1 Bath']);
    setFormData({
      ownerName: property.ownerName,
      ownerEmail: property.ownerEmail,
      ownerPhone: property.ownerPhone,
      address: property.address,
      managerType: property.managerType,
      keyDetails: property.keyDetails,
      notes: property.notes,
      tenantName: property.tenantName || '',
      tenantEmail: property.tenantEmail || '',
      defaultRooms: property.defaultRooms || []
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const propertyData = {
        ...formData,
        defaultRooms: currentRooms
    };

    if (editingId) {
      // Update existing
      setProperties(prev => prev.map(p => 
        p.id === editingId ? { ...p, ...propertyData } : p
      ));
    } else {
      // Create new
      const newProperty: Property = {
        id: generateId(),
        ...propertyData
      };
      setProperties(prev => [...prev, newProperty]);
    }
    
    setIsModalOpen(false);
    setEditingId(null);
  };

  const handleDelete = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (window.confirm('Are you sure you want to delete this property? This action cannot be undone.')) {
      setProperties(prev => prev.filter(p => p.id !== id));
      if (editingId === id) {
        setIsModalOpen(false);
        setEditingId(null);
      }
    }
  };

  const addRoom = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (newRoomInput.trim()) {
        setCurrentRooms([...currentRooms, newRoomInput.trim()]);
        setNewRoomInput('');
    }
  };

  const removeRoom = (index: number) => {
    setCurrentRooms(currentRooms.filter((_, i) => i !== index));
  };

  const loadPreset = (presetName: keyof typeof ROOM_PRESETS) => {
      setCurrentRooms(ROOM_PRESETS[presetName]);
  };

  const filteredProperties = properties.filter(p => 
    p.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.ownerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-500 relative">
      
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Property Manager</h1>
          <p className="text-gray-500">Manage your portfolio, property details and keys.</p>
        </div>
        <button 
          onClick={openAddModal}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-medium transition-colors shadow-sm"
        >
          <Plus size={20} /> Add New Property
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden min-h-[400px]">
        {/* Toolbar */}
        <div className="p-4 border-b border-gray-200 flex gap-4 bg-gray-50">
           <div className="relative flex-1 max-w-md">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
             <input 
               type="text" 
               placeholder="Search by address, owner or email..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
             />
           </div>
        </div>
        
        {/* Content Area */}
        {properties.length === 0 ? (
          <div className="p-16 text-center text-gray-500">
             <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6 text-blue-200">
               <Home size={40} />
             </div>
             <h3 className="text-xl font-bold text-gray-900 mb-2">No properties found</h3>
             <p className="mb-8 max-w-sm mx-auto">Get started by adding your first property to streamline your reports and inspections.</p>
             <button 
                onClick={openAddModal}
                className="text-blue-600 font-semibold hover:text-blue-800 hover:underline"
             >
               + Add New Property
             </button>
          </div>
        ) : (
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProperties.map(property => (
              <div key={property.id} className="border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow bg-white relative group">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center font-bold text-lg">
                      {property.ownerName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{property.ownerName}</h3>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-medium">
                        {property.managerType}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      type="button"
                      onClick={(e) => handleEdit(property, e)}
                      className="text-gray-400 hover:text-blue-600 hover:bg-blue-50 p-2 rounded-full transition-colors"
                      title="Edit Property"
                    >
                      <Edit size={18} />
                    </button>
                    <button 
                      type="button"
                      onClick={(e) => handleDelete(property.id, e)}
                      className="text-gray-400 hover:text-red-600 hover:bg-red-50 p-2 rounded-full transition-colors"
                      title="Delete Property"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-3 text-sm text-gray-600 pt-2 border-t border-gray-100">
                  <div className="flex items-start gap-2">
                    <MapPin size={16} className="text-gray-400 mt-0.5 flex-shrink-0" />
                    <span className="font-medium text-gray-800">{property.address}</span>
                  </div>
                  {property.tenantName && (
                      <div className="flex items-center gap-2 pt-1">
                        <Users size={16} className="text-blue-400" />
                        <span className="text-blue-700">Tenant: {property.tenantName}</span>
                      </div>
                  )}
                   <div className="flex items-center gap-2 pt-1">
                      <LayoutTemplate size={16} className="text-gray-400" />
                      <span className="text-gray-600">
                         {property.defaultRooms && property.defaultRooms.length > 0 
                            ? `${property.defaultRooms.length} Areas configured`
                            : 'No layout configured'}
                      </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add/Edit Property Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center p-6 border-b border-gray-100 flex-shrink-0">
              <h2 className="text-xl font-bold text-gray-900">
                {editingId ? 'Edit Property Details' : 'Add New Property'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="overflow-y-auto p-6 space-y-6">
              <form id="propertyForm" onSubmit={handleSubmit}>
                
                {/* Property Address */}
                <div>
                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide flex items-center gap-2 mb-4">
                      <MapPin size={16} /> Property Location
                    </h3>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Address</label>
                    <input 
                      type="text" 
                      name="address"
                      required
                      value={formData.address}
                      onChange={handleInputChange}
                      className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="e.g. 123 Main St, Suburb WA 6000"
                    />
                </div>

                {/* Property Layout Configuration */}
                <div className="border-t border-gray-100 pt-4 mt-6">
                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide flex items-center gap-2 mb-3">
                      <Layers size={16} /> Property Layout / Areas
                    </h3>
                    <p className="text-xs text-gray-500 mb-4">Define the rooms and areas for this property. These will be used for all inspections sent to tenants.</p>

                    {/* Presets */}
                    <div className="mb-4">
                         <span className="text-xs font-semibold text-gray-600 block mb-2">Quick Presets:</span>
                         <div className="flex flex-wrap gap-2">
                             {Object.keys(ROOM_PRESETS).map(preset => (
                                 <button
                                    key={preset}
                                    type="button"
                                    onClick={() => loadPreset(preset as keyof typeof ROOM_PRESETS)}
                                    className="px-3 py-1 text-xs bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-full text-gray-700 transition"
                                 >
                                    {preset}
                                 </button>
                             ))}
                         </div>
                    </div>

                    {/* Add Room Input */}
                    <div className="flex gap-2 mb-4">
                        <input 
                           type="text"
                           value={newRoomInput}
                           onChange={e => setNewRoomInput(e.target.value)}
                           onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addRoom())}
                           placeholder="Add custom area (e.g. Pool, Granny Flat)"
                           className="flex-1 border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                        />
                        <button 
                           type="button" 
                           onClick={() => addRoom()} 
                           className="bg-blue-600 text-white px-3 rounded-lg hover:bg-blue-700"
                        >
                            <Plus size={18} />
                        </button>
                    </div>

                    {/* Room List */}
                    <div className="bg-gray-50 p-3 rounded-lg border border-gray-200 min-h-[100px]">
                        {currentRooms.length === 0 ? (
                            <p className="text-xs text-gray-400 text-center py-4">No areas defined. Select a preset or add manually.</p>
                        ) : (
                            <div className="flex flex-wrap gap-2">
                                {currentRooms.map((room, idx) => (
                                    <div key={idx} className="bg-white border border-gray-300 text-gray-800 text-sm px-3 py-1 rounded-full flex items-center gap-2 shadow-sm">
                                        {room}
                                        <button 
                                           type="button" 
                                           onClick={() => removeRoom(idx)} 
                                           className="text-gray-400 hover:text-red-500"
                                        >
                                            <X size={14} />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Tenant Details */}
                <div className="border-t border-gray-100 pt-4 mt-6">
                  <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide flex items-center gap-2 mb-4">
                    <Users size={16} /> Tenant Details
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Tenant Name</label>
                          <input 
                            type="text" 
                            name="tenantName"
                            value={formData.tenantName}
                            onChange={handleInputChange}
                            className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                            placeholder="e.g. John Doe"
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Tenant Email</label>
                          <input 
                            type="email" 
                            name="tenantEmail"
                            value={formData.tenantEmail}
                            onChange={handleInputChange}
                            className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                            placeholder="john@example.com"
                          />
                      </div>
                  </div>
                </div>

                {/* Owner Details */}
                <div className="border-t border-gray-100 pt-4 mt-6">
                  <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide flex items-center gap-2 mb-4">
                    <User size={16} /> Owner / Client Details
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Owner Name</label>
                      <input 
                        type="text" 
                        name="ownerName"
                        required
                        value={formData.ownerName}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="e.g. Jane Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Owner Email</label>
                      <input 
                        type="email" 
                        name="ownerEmail"
                        value={formData.ownerEmail}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="jane@example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Owner Phone</label>
                      <input 
                        type="tel" 
                        name="ownerPhone"
                        value={formData.ownerPhone}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="0400 000 000"
                      />
                    </div>
                  </div>
                </div>

                {/* Management Details */}
                <div className="border-t border-gray-100 pt-4 mt-6">
                  <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide flex items-center gap-2 mb-4">
                    <Building size={16} /> Management & Access
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Managed By</label>
                      <select 
                        name="managerType"
                        value={formData.managerType}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                      >
                        <option value="Real Estate">Real Estate Agency</option>
                        <option value="Landlord">Private Landlord</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Key Access Details</label>
                      <select 
                        name="keyDetails"
                        value={formData.keyDetails}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                      >
                        <option value="Held with Agent">Held with Agent</option>
                        <option value="Held with Landlord">Held with Landlord</option>
                        <option value="Safebox">Safebox / Lockbox</option>
                        <option value="Tenant">Tenant to provide access</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Additional Notes</label>
                      <textarea 
                        name="notes"
                        value={formData.notes}
                        onChange={handleInputChange}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none h-20"
                        placeholder="Access codes, specific instructions, etc."
                      ></textarea>
                  </div>
                </div>
              </form>
            </div>

            <div className="p-6 border-t border-gray-100 flex justify-end gap-3 flex-shrink-0 bg-white">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  form="propertyForm"
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium shadow-sm transition-colors"
                >
                  {editingId ? 'Update Property' : 'Save Property'}
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientManager;
