
export interface Photo {
  id: string;
  file: File;
  previewUrl: string;
}

export interface InspectionItem {
  id: string;
  name: string;
  isClean: boolean;
  isUndamaged: boolean;
  isWorking: boolean;
  comment: string;
  // New fields for the AI Review
  aiAnalysis?: string;
  aiFlagged?: boolean; 
}

export interface Room {
  id: string;
  name: string;
  items: InspectionItem[];
  photos: Photo[];
  overallComment: string;
}

export interface Property {
  id: string;
  ownerName: string;
  ownerEmail: string;
  ownerPhone: string;
  address: string;
  managerType: 'Real Estate' | 'Landlord' | 'Other';
  keyDetails: 'Held with Agent' | 'Held with Landlord' | 'Safebox' | 'Tenant' | 'Other';
  notes: string;
  // We can add tenant details here for pre-filling
  tenantName?: string;
  tenantEmail?: string;
  defaultRooms?: string[]; // Configured areas for this property
}

export type ReportType = 'Entry' | 'Exit' | 'Routine' | 'Remote';

export enum RemoteInspectionStatus {
  SENT = 'SENT',
  IN_PROGRESS = 'IN_PROGRESS',
  SUBMITTED = 'SUBMITTED',
  REVIEWED = 'REVIEWED'
}

export interface RemoteInspectionRequest {
  id: string;
  token: string; // Simulates the unique link
  propertyId?: string; // Link to the property DB
  propertyAddress: string;
  tenantName: string;
  tenantEmail: string;
  status: RemoteInspectionStatus;
  dueDate: string;
  reportType: ReportType; // Specific type for this request
  data: ReportData; // Holds the inspection data
}

export interface ReportData {
  id: string;
  type: ReportType;
  propertyAddress: string;
  agentName: string;
  agentCompany: string;
  clientName: string;
  inspectionDate: string;
  tenantName: string;
  rooms: Room[];
}

export enum ReportViewMode {
  EDIT = 'EDIT',
  PREVIEW = 'PREVIEW'
}
