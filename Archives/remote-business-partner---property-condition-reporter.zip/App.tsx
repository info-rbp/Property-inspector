import React, { useState, useEffect, useRef } from 'react';
import { ReportData, Room, ReportViewMode, InspectionItem, Photo, PreviousReportAttachment } from './types';
import RoomForm from './components/RoomForm';
import PDFPreview from './components/PDFPreview';
import { generateId, getInitialItemsForRoom, ROOM_TYPES, processImageFile } from './utils';
import { FileText, Printer, Plus, Eye, Edit2, CheckCircle2, Circle, Image as ImageIcon, Trash2, Upload, ChevronDown, ChevronUp, Save, FolderOpen, Loader2, X, Wand2, Cloud, Bell, HardDrive, Settings, Wifi, WifiOff, FileCheck } from 'lucide-react';
import { saveReportToDB, getAllSavedReports, loadReportFromDB, deleteReportFromDB, isFirebaseConfigured, saveFirebaseConfig, getFirebaseConfig, clearFirebaseConfig } from './services/storageService';
import { generateOverallComment, generateItemComment, generateBatchRoomAnalysis } from './services/geminiService';

const INITIAL_REPORT: ReportData = {
  id: generateId(),
  propertyAddress: '',
  agentName: 'Admin Team',
  agentCompany: 'Remote Business Partner',
  agentAddress: 'Perth, WA',
  agentPhone: '0400 000 000',
  agentEmail: 'real.estate@remotebusinesspartner.com.au',
  clientName: '',
  inspectionDate: new Date().toISOString().split('T')[0],
  tenantName: '',
  reportType: 'Property Condition Report',
  rooms: []
};

const App: React.FC = () => {
  const [report, setReport] = useState<ReportData>(INITIAL_REPORT);
  const [viewMode, setViewMode] = useState<ReportViewMode>(ReportViewMode.EDIT);
  
  // Add Room State
  const [selectedRoomType, setSelectedRoomType] = useState<string>(ROOM_TYPES[0]);
  const [newRoomName, setNewRoomName] = useState('');

  // Saving/Loading State
  const [isSaving, setIsSaving] = useState(false);
  const [showLoadModal, setShowLoadModal] = useState(false);
  const [savedReports, setSavedReports] = useState<ReportData[]>([]);
  const [isLoadingList, setIsLoadingList] = useState(false);
  const [isHydrating, setIsHydrating] = useState(false);
  
  // Settings / Config State
  const [showSettings, setShowSettings] = useState(false);
  const [configForm, setConfigForm] = useState(getFirebaseConfig());

  // Global Generation State
  const [isGlobalGenerating, setIsGlobalGenerating] = useState(false);
  const [globalGenerationStatus, setGlobalGenerationStatus] = useState('');
  const [generationProgress, setGenerationProgress] = useState(0);

  // Hero Image Input Ref
  const heroInputRef = useRef<HTMLInputElement>(null);
  const [isProcessingHero, setIsProcessingHero] = useState(false);

  // Previous Report Input Ref
  const previousReportRef = useRef<HTMLInputElement>(null);

  // Update room name default when type changes
  useEffect(() => {
    setNewRoomName(selectedRoomType);
  }, [selectedRoomType]);

  // Request Notification Permissions on mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  // --- BACKGROUND CAPABILITY: WAKE LOCK MANAGER ---
  useEffect(() => {
    let sentinel: WakeLockSentinel | null = null;

    const requestLock = async () => {
      if (isGlobalGenerating && 'wakeLock' in navigator && !document.hidden) {
        try {
          sentinel = await navigator.wakeLock.request('screen');
        } catch (e) {
          console.warn('Wake lock denied', e);
        }
      }
    };

    const handleVisibilityChange = () => {
      if (!document.hidden && isGlobalGenerating && !sentinel) {
         requestLock();
      }
      if (document.hidden && sentinel) {
         sentinel = null; 
      }
    };

    if (isGlobalGenerating) {
      requestLock();
      document.addEventListener('visibilitychange', handleVisibilityChange);
    }

    return () => {
      if (sentinel) sentinel.release();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isGlobalGenerating]);

  // Safety Guard
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isGlobalGenerating || isSaving) {
        const message = "Work is in progress. Closing this window will stop the report generation.";
        e.returnValue = message;
        return message;
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isGlobalGenerating, isSaving]);

  const updateReport = (updates: Partial<ReportData>) => {
    setReport(prev => ({ ...prev, ...updates }));
  };

  // --- AUDIO HELPER ---
  const playCompletionSound = () => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); 
      osc.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.1); 
      
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);
      
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.8);
    } catch (e) {
      console.error("Audio play failed", e);
    }
  };

  // --- CONFIG HANDLERS ---
  const handleConfigChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setConfigForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSaveConfig = (e: React.FormEvent) => {
      e.preventDefault();
      if (!configForm.apiKey || !configForm.projectId) {
          alert("API Key and Project ID are required.");
          return;
      }
      saveFirebaseConfig(configForm);
  };

  const handleClearConfig = () => {
      if (window.confirm("Disconnect from Cloud? Reports will save to this device only.")) {
          clearFirebaseConfig();
      }
  };

  // --- SAVE / LOAD LOGIC ---

  const handleSaveReport = async () => {
    if (!report.propertyAddress) {
      alert("Please enter a Property Address before saving.");
      return;
    }
    setIsSaving(true);
    try {
      const savedReport = await saveReportToDB(report);
      setReport(savedReport);
      await new Promise(r => setTimeout(r, 500));
      // Generic success message
      const dest = isFirebaseConfigured ? 'Cloud' : 'Device';
      alert(`Report saved to ${dest} successfully!`);
    } catch (error) {
      console.error("Save failed", error);
      alert("Failed to save report. Check console/config.");
    } finally {
      setIsSaving(false);
    }
  };

  const openLoadModal = async () => {
    setShowLoadModal(true);
    setIsLoadingList(true);
    try {
      const reports = await getAllSavedReports();
      reports.sort((a, b) => new Date(b.inspectionDate).getTime() - new Date(a.inspectionDate).getTime());
      setSavedReports(reports);
    } catch (error) {
      console.error("Failed to list reports", error);
      alert("Failed to access saved reports. Check configuration.");
    } finally {
      setIsLoadingList(false);
    }
  };

  const handleLoadReport = async (id: string) => {
    if (window.confirm("Loading a report will overwrite current unsaved changes. Continue?")) {
      setIsHydrating(true);
      try {
        const loadedReport = await loadReportFromDB(id);
        if (loadedReport) {
          report.rooms.forEach(r => r.photos.forEach(p => URL.revokeObjectURL(p.previewUrl)));
          if (report.heroPhoto) URL.revokeObjectURL(report.heroPhoto.previewUrl);
          // Don't need to explicitly revoke previousReport object URL here as loadReport handles simple File creation? 
          // Actually loadReportFromDB creates Files but doesn't create object URLs for the previous report specifically unless we added preview logic.
          // Let's assume we don't preview the PDF inline in this version, just store it.
          
          setReport(loadedReport);
          setShowLoadModal(false);
        } else {
            alert("Report not found or failed to load.");
        }
      } catch (error) {
        console.error("Load failed", error);
        alert("Failed to load report.");
      } finally {
        setIsHydrating(false);
      }
    }
  };

  const handleDeleteSavedReport = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("Permanently delete this saved report?")) {
      try {
        await deleteReportFromDB(id);
        setSavedReports(prev => prev.filter(r => r.id !== id));
      } catch (error) {
        alert("Failed to delete.");
      }
    }
  };

  // --- GENERATE FULL REPORT LOGIC ---
  const handleGenerateFullReport = async () => {
    const roomsWithPhotos = report.rooms.filter(r => r.photos.length > 0);
    
    if (roomsWithPhotos.length === 0) {
      alert("No rooms have photos. Please upload photos to rooms before auto-generating.");
      return;
    }

    const comparisonMsg = (report.previousReport || report.previousReportNotes) 
        ? "COMPARISON MODE: Active\nAI will compare current photos against the provided Previous Report/Notes."
        : "Standard Generation";

    if (!window.confirm(`Ready to auto-fill ${roomsWithPhotos.length} rooms using AI? \n\n${comparisonMsg}\n\nThis will analyze all photos and update comments/checkboxes. Existing text may be refined.`)) {
      return;
    }

    if ('Notification' in window && Notification.permission === 'default') {
       await Notification.requestPermission();
    }

    setIsGlobalGenerating(true);
    setGenerationProgress(0);
    
    try {
      const CHUNK_SIZE = 5;
      const totalSteps = roomsWithPhotos.length;
      
      for (let i = 0; i < roomsWithPhotos.length; i++) {
        const room = roomsWithPhotos[i];
        const roomIndex = report.rooms.findIndex(r => r.id === room.id);
        if (roomIndex === -1) continue;

        const progressPercent = Math.round((i / totalSteps) * 100);
        setGenerationProgress(progressPercent);
        document.title = `(${progressPercent}%) Generating Report...`;

        let currentRoomState = { ...room };

        try {
          for (let p = 0; p < room.photos.length; p += CHUNK_SIZE) {
            setGlobalGenerationStatus(
                `Room ${i + 1}/${roomsWithPhotos.length}: ${room.name}\n` +
                `Analyzing photo batch ${Math.ceil((p + 1)/CHUNK_SIZE)} of ${Math.ceil(room.photos.length/CHUNK_SIZE)}...`
            );
            
            const batchPhotos = room.photos.slice(p, p + CHUNK_SIZE);
            
            const analysisResult = await generateBatchRoomAnalysis(
                room.name,
                batchPhotos,
                currentRoomState.items,
                currentRoomState.overallComment,
                report.previousReport?.file, // PASS PREVIOUS REPORT FILE
                report.previousReportNotes   // PASS PREVIOUS REPORT NOTES
            );

            currentRoomState.overallComment = analysisResult.overallComment || currentRoomState.overallComment;
            
            if (analysisResult.items && analysisResult.items.length > 0) {
                currentRoomState.items = currentRoomState.items.map(item => {
                    const update = analysisResult.items.find(u => u.id === item.name);
                    if (update) {
                        return { ...item, ...update, id: item.id };
                    }
                    return item;
                });
            }

            setReport(prev => {
                const newRooms = [...prev.rooms];
                newRooms[roomIndex] = { ...currentRoomState };
                return { ...prev, rooms: newRooms };
            });

            await new Promise(r => setTimeout(r, 500));
          }
          
           setReport(prev => {
                const newRooms = [...prev.rooms];
                newRooms[roomIndex] = { ...newRooms[roomIndex], status: 'analyzed' };
                return { ...prev, rooms: newRooms };
            });

        } catch (e) {
          console.error(`Error generating batch for ${room.name}`, e);
        }
      }

      setGlobalGenerationStatus("Complete!");
      setGenerationProgress(100);
      document.title = "Report Ready!";
      playCompletionSound();
      
      await new Promise(r => setTimeout(r, 1000));

      if (document.hidden && Notification.permission === 'granted') {
          const notification = new Notification('Report Generation Complete', {
              body: 'Your AI property report is ready for review. Click to return.',
              icon: '/vite.svg', 
              requireInteraction: true
          });
          notification.onclick = () => {
              window.focus();
              notification.close();
          };
      }

    } catch (error) {
      console.error("Global generation failed", error);
      alert("An error occurred during auto-generation. Check console for details.");
    } finally {
      setIsGlobalGenerating(false);
      setGlobalGenerationStatus('');
      setGenerationProgress(0);
      document.title = "Remote Business Partner Property Reports";
    }
  };

  // --- EXISTING HANDLERS ---
  const handleHeroPhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsProcessingHero(true);
      try {
        const file = e.target.files[0];
        const processedFile = await processImageFile(file);
        const newPhoto: Photo = {
          id: generateId(),
          file: processedFile,
          previewUrl: URL.createObjectURL(processedFile)
        };
        updateReport({ heroPhoto: newPhoto });
      } catch (error) {
        console.error("Hero upload failed", error);
        alert("Failed to process image.");
      } finally {
        setIsProcessingHero(false);
        if (heroInputRef.current) heroInputRef.current.value = '';
      }
    }
  };

  const removeHeroPhoto = () => {
    if (report.heroPhoto) {
      URL.revokeObjectURL(report.heroPhoto.previewUrl);
      updateReport({ heroPhoto: undefined });
    }
  };

  const handlePreviousReportSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          const newAttachment: PreviousReportAttachment = {
              id: generateId(),
              file: file,
              name: file.name,
              mimeType: file.type
          };
          updateReport({ previousReport: newAttachment });
          if (previousReportRef.current) previousReportRef.current.value = '';
      }
  };

  const removePreviousReport = () => {
      updateReport({ previousReport: undefined });
  };

  const handleAddRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim()) return;
    const itemNames = getInitialItemsForRoom(selectedRoomType);
    const initialItems: InspectionItem[] = itemNames.map(name => ({
      id: generateId(),
      name,
      isClean: true,
      isUndamaged: true,
      isWorking: true,
      comment: ''
    }));

    const newRoom: Room = {
      id: generateId(),
      name: newRoomName,
      status: 'draft',
      items: initialItems,
      photos: [],
      overallComment: '',
      isExpanded: true
    };

    setReport(prev => ({ ...prev, rooms: [...prev.rooms, newRoom] }));
    setSelectedRoomType(ROOM_TYPES[0]);
    setNewRoomName(ROOM_TYPES[0]);
  };

  const updateRoom = (updatedRoom: Room) => {
    setReport(prev => ({
      ...prev,
      rooms: prev.rooms.map(r => r.id === updatedRoom.id ? updatedRoom : r)
    }));
  };

  const deleteRoom = (roomId: string) => {
    if (window.confirm('Are you sure you want to delete this room?')) {
      setReport(prev => ({
        ...prev,
        rooms: prev.rooms.filter(r => r.id !== roomId)
      }));
    }
  };

  const expandAllRooms = () => {
    setReport(prev => ({ ...prev, rooms: prev.rooms.map(r => ({ ...r, isExpanded: true })) }));
  };

  const collapseAllRooms = () => {
    setReport(prev => ({ ...prev, rooms: prev.rooms.map(r => ({ ...r, isExpanded: false })) }));
  };

  if (viewMode === ReportViewMode.PREVIEW) {
    return (
      <div className="min-h-screen bg-gray-600 py-8 print:bg-white print:p-0 print:m-0 print:h-auto print:w-full">
        <div className="fixed top-4 right-4 flex gap-4 no-print z-50">
          <button onClick={() => window.print()} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 font-medium">
            <Printer size={20} /> Print / Save PDF
          </button>
          <button onClick={() => setViewMode(ReportViewMode.EDIT)} className="bg-white hover:bg-gray-100 text-gray-800 px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 font-medium">
            <Edit2 size={20} /> Back to Edit
          </button>
        </div>
        <PDFPreview data={report} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 relative">
      
      {/* Global Progress Overlay */}
      {isGlobalGenerating && (
        <div className="fixed inset-0 bg-black/70 z-50 flex flex-col items-center justify-center p-4 backdrop-blur-sm transition-opacity duration-300">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center border-t-4 border-purple-600 transform scale-100 animate-in zoom-in-95 duration-200">
            <div className="mb-4 flex justify-center">
               <div className="relative">
                 <div className="w-16 h-16 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
                 <div className="absolute inset-0 flex items-center justify-center">
                   <Wand2 size={24} className="text-purple-600 animate-pulse" />
                 </div>
               </div>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">AI is Generating Report</h3>
            <p className="text-sm text-gray-500 mb-4">{generationProgress}% Complete</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
               <div className="bg-purple-600 h-2 rounded-full transition-all duration-300" style={{ width: `${generationProgress}%` }}></div>
            </div>
            <div className="bg-gray-100 rounded-lg p-4 font-mono text-xs text-left text-gray-700 h-24 overflow-hidden relative mb-4">
               <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-100 pointer-events-none"></div>
               <pre className="whitespace-pre-wrap break-words">{globalGenerationStatus}</pre>
            </div>
          </div>
        </div>
      )}

      {/* Hydration Overlay */}
      {isHydrating && (
        <div className="fixed inset-0 bg-white/80 z-50 flex flex-col items-center justify-center p-4 backdrop-blur-sm">
            <Loader2 className="animate-spin text-blue-600 mb-2" size={40} />
            <h3 className="text-lg font-bold text-gray-800">Downloading...</h3>
            <p className="text-sm text-gray-500">Restoring images for editing...</p>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 animate-in zoom-in-95 duration-200">
                <div className="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
                    <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                        <Settings size={24} className="text-blue-600"/> Cloud Configuration
                    </h2>
                    <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-gray-600"><X size={24}/></button>
                </div>
                
                <p className="text-sm text-gray-500 mb-4 bg-blue-50 p-3 rounded-lg border border-blue-100">
                    Enter your provisioned Firebase credentials here to enable Cloud Storage. 
                    If left blank, reports will save to this device only.
                </p>

                <form onSubmit={handleSaveConfig} className="space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">API Key</label>
                        <input name="apiKey" value={configForm.apiKey || ''} onChange={handleConfigChange} className="w-full border border-gray-300 rounded p-2 text-sm font-mono" placeholder="AIza..." required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Project ID</label>
                            <input name="projectId" value={configForm.projectId || ''} onChange={handleConfigChange} className="w-full border border-gray-300 rounded p-2 text-sm font-mono" placeholder="my-project-id" required />
                        </div>
                         <div>
                            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Auth Domain</label>
                            <input name="authDomain" value={configForm.authDomain || ''} onChange={handleConfigChange} className="w-full border border-gray-300 rounded p-2 text-sm font-mono" placeholder="project.firebaseapp.com" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Storage Bucket</label>
                        <input name="storageBucket" value={configForm.storageBucket || ''} onChange={handleConfigChange} className="w-full border border-gray-300 rounded p-2 text-sm font-mono" placeholder="project.appspot.com" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Sender ID</label>
                            <input name="messagingSenderId" value={configForm.messagingSenderId || ''} onChange={handleConfigChange} className="w-full border border-gray-300 rounded p-2 text-sm font-mono" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">App ID</label>
                            <input name="appId" value={configForm.appId || ''} onChange={handleConfigChange} className="w-full border border-gray-300 rounded p-2 text-sm font-mono" />
                        </div>
                    </div>

                    <div className="flex justify-between pt-4 border-t border-gray-100">
                        {isFirebaseConfigured ? (
                             <button type="button" onClick={handleClearConfig} className="text-red-600 text-sm hover:underline">Disconnect Cloud</button>
                        ) : <div></div>}
                        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-bold shadow-sm transition">Save & Reload</button>
                    </div>
                </form>
            </div>
        </div>
      )}

      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
             <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded text-white flex items-center justify-center font-bold">RB</div>
                <span className="font-bold text-xl text-gray-900 hidden sm:block">Remote Business Partner</span>
                <span className="font-bold text-xl text-gray-900 sm:hidden">RBP</span>
                {isFirebaseConfigured ? (
                     <div className="ml-2 flex items-center gap-1 bg-green-50 text-green-700 text-[10px] px-2 py-0.5 rounded-full border border-green-200 font-bold" title="Connected to Cloud">
                        <Cloud size={10} /> CLOUD
                     </div>
                ) : (
                     <div className="ml-2 flex items-center gap-1 bg-gray-100 text-gray-500 text-[10px] px-2 py-0.5 rounded-full border border-gray-200 font-bold" title="Local Device Storage Only">
                        <HardDrive size={10} /> DEVICE
                     </div>
                )}
             </div>
             <div className="flex items-center gap-2 md:gap-3">
                <button 
                  onClick={() => setShowSettings(true)}
                  className="text-gray-500 hover:bg-gray-100 p-2 rounded-lg transition"
                  title="Cloud Configuration"
                >
                    <Settings size={20} />
                </button>
                <div className="h-6 w-px bg-gray-300 mx-1"></div>
                <button 
                  onClick={handleSaveReport}
                  disabled={isSaving || isGlobalGenerating || isHydrating}
                  className="bg-gray-100 text-gray-700 hover:bg-gray-200 px-3 py-2 rounded-lg text-sm font-medium transition flex items-center gap-2 disabled:opacity-50"
                  title="Save Report"
                >
                   {isSaving ? <Loader2 size={16} className="animate-spin"/> : <Save size={16} />} 
                   <span className="hidden sm:inline">{isSaving ? 'Saving...' : 'Save'}</span>
                </button>
                <button 
                  onClick={openLoadModal}
                  disabled={isGlobalGenerating || isHydrating}
                  className="bg-gray-100 text-gray-700 hover:bg-gray-200 px-3 py-2 rounded-lg text-sm font-medium transition flex items-center gap-2 disabled:opacity-50"
                  title="Open Saved Report"
                >
                    <FolderOpen size={16} /> 
                    <span className="hidden sm:inline">Open</span>
                </button>
                <div className="h-6 w-px bg-gray-300 mx-1"></div>
                <button 
                  onClick={() => setViewMode(ReportViewMode.PREVIEW)}
                  disabled={isGlobalGenerating || isHydrating}
                  className="bg-gray-900 text-white px-3 md:px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 transition flex items-center gap-2 disabled:opacity-50"
                >
                    <Eye size={16} /> <span className="hidden sm:inline">Preview Report</span>
                    <span className="sm:hidden">Preview</span>
                </button>
             </div>
          </div>
        </div>
      </nav>

      {/* Load Report Modal */}
      {showLoadModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[80vh] flex flex-col">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                 {isFirebaseConfigured ? <Cloud size={24} className="text-blue-500"/> : <HardDrive size={24} className="text-gray-500"/>}
                 {isFirebaseConfigured ? 'Cloud Reports' : 'Local Device Reports'}
              </h2>
              <button onClick={() => setShowLoadModal(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1">
              {isLoadingList ? (
                <div className="flex justify-center py-8"><Loader2 className="animate-spin text-blue-500" size={32} /></div>
              ) : savedReports.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <FolderOpen size={48} className="mx-auto mb-3 opacity-20" />
                  <p>No saved reports found {isFirebaseConfigured ? 'in Cloud' : 'on this device'}.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {savedReports.map((r) => (
                    <div 
                      key={r.id} 
                      onClick={() => handleLoadReport(r.id)}
                      className="border border-gray-200 rounded-lg p-4 hover:border-blue-500 hover:bg-blue-50 cursor-pointer transition group flex justify-between items-center"
                    >
                      <div>
                        <h3 className="font-bold text-gray-900">{r.propertyAddress || 'Untitled Property'}</h3>
                        <p className="text-sm text-gray-500">
                          Date: {r.inspectionDate} &bull; {r.rooms.length} Rooms &bull; {r.reportType}
                        </p>
                      </div>
                      <button 
                        onClick={(e) => handleDeleteSavedReport(r.id, e)}
                        className="text-gray-400 hover:text-red-500 p-2 opacity-0 group-hover:opacity-100 transition"
                        title="Delete"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            <div className="p-4 bg-gray-50 border-t border-gray-200 text-xs text-gray-500 rounded-b-xl flex items-center gap-2">
              {isFirebaseConfigured ? (
                 <><Cloud size={14} /> Synced with Firebase Cloud Storage.</>
              ) : (
                 <><HardDrive size={14} /> Reports are stored on this device only.</>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8 relative overflow-hidden">
          
          <div className="flex flex-col md:flex-row justify-between items-start mb-6 gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
                 <FileText size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">New Inspection Report</h1>
                <p className="text-gray-500">Fill in the details below to generate the Form 1 Condition Report.</p>
              </div>
            </div>

            <button
                onClick={handleGenerateFullReport}
                disabled={isGlobalGenerating}
                className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-3 rounded-lg shadow-md flex items-center gap-2 font-semibold disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105 active:scale-95 group"
            >
                {isGlobalGenerating ? <Loader2 size={20} className="animate-spin" /> : <Wand2 size={20} className="group-hover:rotate-12 transition-transform" />}
                {isGlobalGenerating ? 'Analyzing Report...' : 'Auto-Fill Report with AI'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Property Address</label>
              <input
                type="text"
                value={report.propertyAddress}
                onChange={(e) => updateReport({ propertyAddress: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="e.g., 7 Riley St, Tuart Hill, WA 6060"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Client / Landlord</label>
              <input
                type="text"
                value={report.clientName}
                onChange={(e) => updateReport({ clientName: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="On behalf of..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Inspector Name</label>
              <input
                type="text"
                value={report.agentName}
                onChange={(e) => updateReport({ agentName: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
              <input
                type="text"
                value={report.agentCompany}
                onChange={(e) => updateReport({ agentCompany: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company Address</label>
              <input
                type="text"
                value={report.agentAddress || ''}
                onChange={(e) => updateReport({ agentAddress: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="e.g. Perth, WA"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company Phone/Email</label>
              <input
                type="text"
                value={report.agentPhone || ''}
                onChange={(e) => updateReport({ agentPhone: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="Phone or Email"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Inspection Date</label>
              <input
                type="date"
                value={report.inspectionDate}
                onChange={(e) => updateReport({ inspectionDate: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tenant Name(s)</label>
              <input
                type="text"
                value={report.tenantName}
                onChange={(e) => updateReport({ tenantName: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="e.g., John Doe"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Report Type</label>
              <select
                value={report.reportType}
                onChange={(e) => updateReport({ reportType: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value="Property Condition Report">Property Condition Report (Entry)</option>
                <option value="Routine Inspection">Routine Inspection</option>
                <option value="Exit Inspection">Exit Inspection</option>
              </select>
            </div>
          </div>
          
          {/* Comparison Report Section - Shows ONLY for Routine/Exit */}
          {(report.reportType === 'Routine Inspection' || report.reportType === 'Exit Inspection') && (
            <div className="border-t border-gray-100 pt-6 mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Previous Report for Comparison (Optional)</label>
                <p className="text-xs text-gray-500 mb-3">Upload a PDF/Image OR paste text notes from the previous report. The AI will compare current photos against this baseline.</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* File Upload Section */}
                    <div>
                        {report.previousReport ? (
                            <div className="flex items-center justify-between bg-amber-50 border border-amber-200 rounded-lg p-3 h-full">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 bg-amber-100 rounded text-amber-700">
                                        <FileCheck size={20} />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-gray-800">{report.previousReport.name}</p>
                                        <p className="text-xs text-gray-500 uppercase">{report.previousReport.mimeType.split('/')[1]} File Attached</p>
                                    </div>
                                </div>
                                <button onClick={removePreviousReport} className="text-red-500 hover:text-red-700 p-2">
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        ) : (
                            <div 
                                onClick={() => previousReportRef.current?.click()}
                                className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-amber-400 hover:bg-amber-50 transition h-full min-h-[100px]"
                            >
                                <input 
                                    type="file" 
                                    ref={previousReportRef} 
                                    className="hidden" 
                                    accept=".pdf,image/*"
                                    onChange={handlePreviousReportSelect}
                                />
                                <Upload className="text-gray-400 mb-2" size={24} />
                                <span className="text-sm text-gray-600 font-medium">Upload File (PDF/Image)</span>
                            </div>
                        )}
                    </div>

                    {/* Text Section */}
                    <div className="flex flex-col">
                         <div className="border border-gray-300 rounded-lg p-3 h-full flex flex-col bg-white">
                             <label className="text-xs font-bold text-gray-500 mb-2 uppercase flex items-center gap-2">
                                <FileText size={14} /> Text Notes (Optional)
                             </label>
                             <textarea
                                value={report.previousReportNotes || ''}
                                onChange={(e) => updateReport({ previousReportNotes: e.target.value })}
                                className="flex-1 w-full text-sm p-2 border border-gray-200 rounded resize-none focus:ring-2 focus:ring-blue-500 focus:outline-none"
                                placeholder="e.g. 'Kitchen walls had minor scuff marks near entry. Carpet was professionally cleaned but had one stain in corner.'"
                             />
                         </div>
                    </div>
                </div>
            </div>
          )}

          {/* Hero Photo Section */}
          <div className="border-t border-gray-100 pt-6">
             <label className="block text-sm font-medium text-gray-700 mb-3">Main Property Photo (Cover Page)</label>
             
             {report.heroPhoto ? (
               <div className="relative w-64 aspect-video rounded-lg overflow-hidden border border-gray-200 group">
                  <img src={report.heroPhoto.previewUrl} alt="Hero" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                      <button onClick={removeHeroPhoto} className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition">
                         <Trash2 size={20} />
                      </button>
                  </div>
               </div>
             ) : (
               <div 
                 onClick={() => heroInputRef.current?.click()}
                 className={`w-64 h-36 border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer transition
                   ${isProcessingHero ? 'bg-gray-50 border-gray-300' : 'border-blue-300 bg-blue-50 hover:bg-blue-100'}
                 `}
               >
                 <input 
                    type="file" 
                    ref={heroInputRef} 
                    className="hidden" 
                    accept="image/*,.heic,.heif"
                    onChange={handleHeroPhotoSelect}
                    disabled={isProcessingHero}
                 />
                 {isProcessingHero ? (
                    <span className="text-sm text-gray-500 animate-pulse">Processing...</span>
                 ) : (
                    <>
                       <ImageIcon className="text-blue-400 mb-2" size={24} />
                       <span className="text-sm text-blue-600 font-medium">Upload Cover Photo</span>
                    </>
                 )}
               </div>
             )}
          </div>
        </div>

        {/* Room Management */}
        <div className="mb-8">
           <div className="flex justify-between items-center mb-4">
               <h2 className="text-xl font-bold text-gray-900">Rooms & Areas</h2>
               <div className="flex items-center gap-4">
                  <div className="flex gap-2 mr-4">
                     <button onClick={expandAllRooms} className="text-xs bg-white border border-gray-300 px-2 py-1 rounded hover:bg-gray-50 flex items-center gap-1">
                        <ChevronDown size={14}/> Expand All
                     </button>
                     <button onClick={collapseAllRooms} className="text-xs bg-white border border-gray-300 px-2 py-1 rounded hover:bg-gray-50 flex items-center gap-1">
                        <ChevronUp size={14}/> Collapse All
                     </button>
                  </div>
                  <div className="flex gap-4 text-xs font-medium text-gray-500">
                      <div className="flex items-center gap-1"><Circle size={10} className="text-gray-300 fill-current"/> Draft</div>
                      <div className="flex items-center gap-1"><Circle size={10} className="text-blue-500 fill-current"/> Ready</div>
                      <div className="flex items-center gap-1"><CheckCircle2 size={12} className="text-green-500"/> Analyzed</div>
                  </div>
               </div>
           </div>
           
           {report.rooms.length === 0 ? (
             <div className="text-center py-12 bg-white border border-dashed border-gray-300 rounded-xl mb-6">
                <p className="text-gray-500 mb-2">No rooms added yet.</p>
                <p className="text-sm text-gray-400">Add a room like "Kitchen" or "Entry" to start.</p>
             </div>
           ) : (
             report.rooms.map(room => (
               <div key={room.id} className="relative">
                  {/* Status Indicator Line */}
                  <div className={`absolute left-0 top-0 bottom-6 w-1 rounded-l-lg z-10 
                    ${room.status === 'analyzed' ? 'bg-green-500' : 
                      room.status === 'photos_uploaded' ? 'bg-blue-500' : 'bg-gray-300'}`} 
                  />
                  <RoomForm 
                    room={room} 
                    onUpdate={updateRoom}
                    onDelete={() => deleteRoom(room.id)}
                    previousReport={report.previousReport} // Pass Previous Report File
                    previousReportNotes={report.previousReportNotes} // Pass Previous Report Notes
                  />
               </div>
             ))
           )}

           {/* Add Room Form */}
           <div className="bg-gray-100 p-4 rounded-lg">
             <form onSubmit={handleAddRoom} className="flex flex-col md:flex-row gap-4 items-end md:items-center">
               <div className="flex-1 w-full">
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Area / Room Type</label>
                  <select
                    value={selectedRoomType}
                    onChange={(e) => setSelectedRoomType(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                  >
                    {ROOM_TYPES.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
               </div>
               
               <div className="flex-1 w-full">
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Display Name (Editable)</label>
                  <input
                    type="text"
                    value={newRoomName}
                    onChange={(e) => setNewRoomName(e.target.value)}
                    placeholder="e.g. Master Bedroom"
                    className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
               </div>

               <button 
                 type="submit"
                 className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium flex items-center gap-2 disabled:opacity-50 h-10 w-full md:w-auto justify-center"
                 disabled={!newRoomName.trim()}
               >
                 <Plus size={20} /> Add Room
               </button>
             </form>
           </div>
        </div>
      </div>
    </div>
  );
};

export default App;