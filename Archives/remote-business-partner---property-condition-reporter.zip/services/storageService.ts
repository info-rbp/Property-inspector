import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, getDoc, getDocs, deleteDoc } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { openDB } from 'idb';
import { ReportData, Room, Photo, PreviousReportAttachment } from '../types';

// --- CONFIGURATION MANAGEMENT ---
const CONFIG_KEY = 'rbp_firebase_config';

export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

export const getFirebaseConfig = (): FirebaseConfig => {
  try {
    const stored = localStorage.getItem(CONFIG_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {} as FirebaseConfig;
  }
};

export const saveFirebaseConfig = (config: FirebaseConfig) => {
  localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  window.location.reload(); // Reload to re-initialize Firebase
};

export const clearFirebaseConfig = () => {
  localStorage.removeItem(CONFIG_KEY);
  window.location.reload();
};

// --- INITIALIZATION ---
const storedConfig = getFirebaseConfig();

const firebaseConfig = {
  apiKey: storedConfig.apiKey || "YOUR_API_KEY_HERE",
  authDomain: storedConfig.authDomain || "YOUR_PROJECT.firebaseapp.com",
  projectId: storedConfig.projectId || "YOUR_PROJECT_ID",
  storageBucket: storedConfig.storageBucket || "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: storedConfig.messagingSenderId || "SENDER_ID",
  appId: storedConfig.appId || "APP_ID"
};

export const isFirebaseConfigured = 
  firebaseConfig.apiKey !== "YOUR_API_KEY_HERE" && 
  firebaseConfig.apiKey.length > 0 &&
  firebaseConfig.projectId !== "YOUR_PROJECT_ID";

let db: any;
let storage: any;

if (isFirebaseConfigured) {
    try {
      const app = initializeApp(firebaseConfig);
      db = getFirestore(app);
      storage = getStorage(app);
      console.log("Firebase initialized successfully");
    } catch (e) {
      console.error("Firebase Initialization Failed", e);
    }
} else {
    console.log("Firebase not configured. Using Local Storage (IndexedDB).");
}

const COLLECTION_NAME = 'reports';
const LOCAL_DB_NAME = 'rbp-reports-db';
const LOCAL_STORE_NAME = 'reports';

// --- LOCAL STORAGE HELPERS (IndexedDB) ---

const initLocalDB = async () => {
  return openDB(LOCAL_DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(LOCAL_STORE_NAME)) {
        db.createObjectStore(LOCAL_STORE_NAME, { keyPath: 'id' });
      }
    },
  });
};

export const getLocalReports = async (): Promise<ReportData[]> => {
    const localDB = await initLocalDB();
    return localDB.getAll(LOCAL_STORE_NAME);
};

export const deleteLocalReport = async (id: string): Promise<void> => {
    const localDB = await initLocalDB();
    await localDB.delete(LOCAL_STORE_NAME, id);
};

// --- HELPER: Upload Generic File (Cloud Only) ---
const uploadFileToCloud = async (reportId: string, fileObj: File, id: string): Promise<string> => {
  if (!storage) throw new Error("Firebase Storage not initialized");
  
  const storageRef = ref(storage, `reports/${reportId}/${id}_${fileObj.name}`);
  const snapshot = await uploadBytes(storageRef, fileObj);
  return await getDownloadURL(snapshot.ref);
};

// --- SAVE ---
export const saveReportToDB = async (report: ReportData): Promise<ReportData> => {
  // FALLBACK: Local Storage
  if (!isFirebaseConfigured || !db) {
    const localDB = await initLocalDB();
    const reportToSave = { ...report, lastModified: new Date().toISOString() };
    await localDB.put(LOCAL_STORE_NAME, reportToSave);
    return reportToSave;
  }

  // CLOUD STORAGE STRATEGY
  
  // 1. Upload Hero Photo
  let updatedHero = report.heroPhoto;
  if (updatedHero && updatedHero.file && !updatedHero.downloadUrl) {
    const url = await uploadFileToCloud(report.id, updatedHero.file, updatedHero.id);
    updatedHero = { ...updatedHero, downloadUrl: url };
  }

  // 2. Upload Previous Report Attachment
  let updatedPreviousReport = report.previousReport;
  if (updatedPreviousReport && updatedPreviousReport.file && !updatedPreviousReport.downloadUrl) {
      const url = await uploadFileToCloud(report.id, updatedPreviousReport.file, updatedPreviousReport.id);
      updatedPreviousReport = { ...updatedPreviousReport, downloadUrl: url };
  }

  // 3. Upload Room Photos
  const updatedRooms = await Promise.all(report.rooms.map(async (room) => {
    const updatedPhotos = await Promise.all(room.photos.map(async (photo) => {
      try {
        if (!photo.downloadUrl) {
             const url = await uploadFileToCloud(report.id, photo.file, photo.id);
             return { ...photo, downloadUrl: url };
        }
        return photo;
      } catch (e) {
        console.error(`Failed to upload photo ${photo.id}`, e);
        return photo;
      }
    }));
    return { ...room, photos: updatedPhotos };
  }));

  const updatedReport = {
    ...report,
    heroPhoto: updatedHero,
    previousReport: updatedPreviousReport,
    rooms: updatedRooms
  };

  // 4. Prepare JSON for Firestore (Strip Files/Blobs)
  const firestoreData = {
    ...updatedReport,
    heroPhoto: updatedHero ? { 
        id: updatedHero.id, 
        downloadUrl: updatedHero.downloadUrl, 
        tags: updatedHero.tags,
        fileName: updatedHero.file.name,
        fileType: updatedHero.file.type 
    } : null,
    previousReport: updatedPreviousReport ? {
        id: updatedPreviousReport.id,
        downloadUrl: updatedPreviousReport.downloadUrl,
        name: updatedPreviousReport.file.name,
        mimeType: updatedPreviousReport.file.type
    } : null,
    rooms: updatedRooms.map(r => ({
      ...r,
      photos: r.photos.map(p => ({
        id: p.id,
        downloadUrl: p.downloadUrl,
        tags: p.tags,
        fileName: p.file.name,
        fileType: p.file.type
      }))
    }))
  };

  await setDoc(doc(db, COLLECTION_NAME, report.id), firestoreData);
  return updatedReport;
};

// --- HYDRATION HELPER (Cloud Only) ---
const urlToFile = async (url: string, fileName: string, mimeType: string): Promise<File> => {
  const res = await fetch(url);
  const blob = await res.blob();
  return new File([blob], fileName, { type: mimeType });
};

// --- LOAD ---
export const loadReportFromDB = async (id: string): Promise<ReportData | undefined> => {
  
  // FALLBACK: Local Storage
  if (!isFirebaseConfigured || !db) {
    const localDB = await initLocalDB();
    const data = await localDB.get(LOCAL_STORE_NAME, id);
    if (!data) return undefined;

    // Restore Blob URLs
    const restoredRooms = data.rooms.map((room: Room) => ({
        ...room,
        photos: room.photos.map((p: Photo) => ({
            ...p,
            previewUrl: URL.createObjectURL(p.file)
        }))
    }));

    let restoredHero = undefined;
    if (data.heroPhoto) {
        restoredHero = {
            ...data.heroPhoto,
            previewUrl: URL.createObjectURL(data.heroPhoto.file)
        };
    }

    return { ...data, rooms: restoredRooms, heroPhoto: restoredHero };
  }

  // CLOUD STRATEGY
  const docRef = doc(db, COLLECTION_NAME, id);
  const docSnap = await getDoc(docRef);

  if (!docSnap.exists()) return undefined;

  const data = docSnap.data() as any;

  // Hydrate Hero
  let heroPhoto: Photo | undefined = undefined;
  if (data.heroPhoto && data.heroPhoto.downloadUrl) {
    try {
      const file = await urlToFile(data.heroPhoto.downloadUrl, data.heroPhoto.fileName || 'hero.jpg', data.heroPhoto.fileType || 'image/jpeg');
      heroPhoto = {
        id: data.heroPhoto.id,
        file: file,
        previewUrl: URL.createObjectURL(file),
        downloadUrl: data.heroPhoto.downloadUrl,
        tags: data.heroPhoto.tags
      };
    } catch (e) {
      console.error("Failed to hydrate hero", e);
    }
  }

  // Hydrate Previous Report Attachment
  let previousReport: PreviousReportAttachment | undefined = undefined;
  if (data.previousReport && data.previousReport.downloadUrl) {
      try {
          const file = await urlToFile(data.previousReport.downloadUrl, data.previousReport.name || 'report.pdf', data.previousReport.mimeType || 'application/pdf');
          previousReport = {
              id: data.previousReport.id,
              file: file,
              name: data.previousReport.name,
              mimeType: data.previousReport.mimeType,
              downloadUrl: data.previousReport.downloadUrl
          };
      } catch (e) {
          console.error("Failed to hydrate previous report", e);
      }
  }

  // Hydrate Rooms
  const rooms: Room[] = await Promise.all(data.rooms.map(async (roomData: any) => {
    const photos: Photo[] = await Promise.all(roomData.photos.map(async (pData: any) => {
        try {
            if (!pData.downloadUrl) return null;
            const file = await urlToFile(pData.downloadUrl, pData.fileName || 'photo.jpg', pData.fileType || 'image/jpeg');
            return {
                id: pData.id,
                file: file,
                previewUrl: URL.createObjectURL(file),
                downloadUrl: pData.downloadUrl,
                tags: pData.tags
            } as Photo;
        } catch (e) {
            console.error("Failed to hydrate photo", pData.id, e);
            return null;
        }
    }));

    return {
        ...roomData,
        photos: photos.filter(p => p !== null) as Photo[]
    };
  }));

  return { ...data, heroPhoto, previousReport, rooms };
};

// --- LIST ALL ---
export const getAllSavedReports = async (): Promise<ReportData[]> => {
  if (!isFirebaseConfigured || !db) {
      const localDB = await initLocalDB();
      return localDB.getAll(LOCAL_STORE_NAME);
  }
  const querySnapshot = await getDocs(collection(db, COLLECTION_NAME));
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ReportData));
};

// --- DELETE ---
export const deleteReportFromDB = async (id: string): Promise<void> => {
  if (!isFirebaseConfigured || !db) {
      const localDB = await initLocalDB();
      await localDB.delete(LOCAL_STORE_NAME, id);
      return;
  }
  await deleteDoc(doc(db, COLLECTION_NAME, id));
};