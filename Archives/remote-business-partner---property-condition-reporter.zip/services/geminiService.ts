import { GoogleGenAI } from "@google/genai";
import { Photo, InspectionItem } from "../types";
import { fileToBase64 } from "../utils";

const GEMINI_MODEL = "gemini-2.5-flash";

const GLOBAL_RULES = `
1. GLOBAL RULES FOR ALL ITEMS:
   - Object Presence & Visibility: Never default to "not visible" if ANY part is present. Partial view (corner of window, edge of floor) = VISIBLE. Confirm presence and comment on the visible portion.
   - Contextual Reasoning: Infer context. If a shower head is visible, a shower area exists. If a toilet is visible, flooring exists beneath it.
   - Condition Language:
     * Good/Satisfactory: intact, secure, functional, minor marks only.
     * Fair/Minor wear: light scuffs, small chips, aged but functional.
     * Poor/Defective: broken, loose, stained, corroded, unsafe.
   - Evidence Types: Look for surface condition (cracks, peeling), Geometry (sagging, gaps), Moisture (bubbling, mould), and Function (handles, switches).

2. "NOT APPLICABLE" LOGIC:
   - Only use "Not Applicable" if the item is GENUINELY not in the room (e.g., no bath in a powder room).
   - Do NOT use it for "not visible". If likely present but hidden, say: "Not fully visible in provided images; condition cannot be confirmed."

3. LANGUAGE & TONE:
   - Strictly use Australian English spelling and terminology (e.g., "mould" not "mold", "colour" not "color", "aluminium", "programme").
   - Tone: Professional, objective, factual, and concise suitable for a legal property condition report.
`;

const ITEM_GUIDELINES: Record<string, string> = {
  "front door": "Check surface (dents, cracks, peeling), edges (gaps), hardware (locks, hinges aligned), threshold/seals. Good = solid, aligned. Defect = warping, security issues.",
  "screen door": "Check mesh (tears, sagging), frame (corrosion, dents), locks/hinges. Good = aligned, mesh intact.",
  "walls": "Check vertical planes. Look for cracks (hairline vs structural), impact damage (holes), stains (moisture/mould), peeling paint. Hairline = cosmetic. Swelling = moisture.",
  "flooring": "Check tiles (cracks, loose grout), carpet (stains, pile wear, fraying), timber (scratches, cupping).",
  "ceiling": "Check for sagging, water stains (yellow/brown rings), mould spots, cornice cracking.",
  "windows": "Check glass (cracks), frames (corrosion, rot), seals (perished), mechanisms (winders/locks). Flyscreens present/intact?",
  "blinds/curtains": "Check operation (cords, wands), slats (bent, missing), fabric (stains, tears, sun damage).",
  "light fittings": "Check covers (cracked/missing), bugs/dust inside, bulbs present. Loose fittings?",
  "power points": "Check covers (cracks, paint splashes), secure mounting. Visibly undamaged?",
  "kitchen benchtop": "Check edges (chipping, lifting laminate), surface (cuts, burns, swelling at joins). Swelling = water damage.",
  "sink/taps": "Check stainless steel (scratches, dents), silicone seal (mould, gaps), tap operation (drips if visible).",
  "oven/stove": "Check glass (clean/intact), elements/burners (corrosion), seals, cleanliness (grease).",
  "rangehood": "Check filters (grease build-up), lights working, fan buttons intact.",
  "dishwasher": "Check seal cleanliness, door spring, control panel legibility.",
  "cupboards/drawers": "Check hinges (sagging), runners (smooth), laminate condition (peeling/swelling especially near water).",
  "shower": "Check screen (cracks, water stains), silicone (mould, gaps), grout (missing/discoloured), drain (clear).",
  "vanity": "Check cabinet swelling (water damage at base), basin cracks, mirror desilvering.",
  "toilet": "Check bowl (cleanliness), seat (loose/stained), cistern (cracked), base seal.",
  "tubs": "Check for rust spots, cabinet swelling, tap condition.",
  "garage door": "Check panels (dents), guides (straight), motor unit present.",
  "driveway": "Check concrete/paving (oil stains, cracking, subsidence, weeds).",
  "fences": "Check vertical alignment (leaning), palings (missing/rot), asbestos (if older).",
  "gardens": "Check weeds, plant health, mulch levels, edging condition.",
  "lawns": "Check coverage (bare patches), weeds, length (overgrown).",
  "smoke alarms": "Check presence, secure mounting, green light (if visible).",
  "rcd/safety switch": "Check switchboard presence.",
  "pool": "Check water clarity, surfaces (tiles/liner), equipment (pump/filter). Check Fencing/Gates for compliance (self-closing, gaps).",
  "cpr": "Check for presence of resuscitation chart, legibility, and visibility within the pool area."
};

const getGuidelinesForItem = (itemName: string): string => {
  const lowerItem = itemName.toLowerCase();
  for (const [key, guide] of Object.entries(ITEM_GUIDELINES)) {
    if (lowerItem.includes(key) || key.includes(lowerItem)) return guide;
  }
  return "Assess cleanliness, damage, and working order based on visual evidence.";
};

// Helper to construct comparison context
const getComparisonContext = (file?: File, notes?: string) => {
    if (!file && !notes) return "";
    
    let instruction = `
    CRITICAL COMPARISON TASK:
    A previous condition report context is provided.
    You MUST compare the visual evidence in the current photos against the description in the previous report.
    `;
    
    if (file) instruction += `\nA PDF/Image file of the previous report is attached. Refer to it for the previous state of this room.\n`;
    if (notes) instruction += `\nRelevant notes from the previous report: "${notes}". Use these text notes as the baseline for comparison.\n`;
    
    instruction += `
    - Identify any NEW damage, wear, or deterioration.
    - Identify any repairs or improvements made since the last report.
    - If the previous report mentions a defect (e.g., 'stain on carpet') and it is still visible, note that it remains.
    - If the previous report says 'Clean' but photos show it dirty, highlight the degradation.
    `;
    
    return instruction;
};

// Helper to interact with AI
const callGemini = async (prompt: string, photos: Photo[], previousReportFile?: File, responseSchema?: any): Promise<string> => {
  if (!process.env.API_KEY) throw new Error("API Key missing");
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // 1. Convert Current Photos to parts
  const parts: any[] = await Promise.all(photos.map(async (p) => {
    const reader = new FileReader();
    return new Promise<any>((resolve) => {
        reader.onload = () => {
            const b64 = (reader.result as string).split(',')[1];
            resolve({ inlineData: { mimeType: p.file.type || 'image/jpeg', data: b64 } });
        };
        reader.readAsDataURL(p.file);
    });
  }));

  // 2. Add Previous Report if available (PDF or Image)
  if (previousReportFile) {
    try {
        const b64 = await fileToBase64(previousReportFile);
        // Add as a separate part. Gemini handles application/pdf.
        parts.push({ 
            inlineData: { 
                mimeType: previousReportFile.type, 
                data: b64 
            } 
        });
        parts.push({ text: "\n[SYSTEM NOTE]: A Previous Condition Report is attached above. Use it for comparison as requested in the prompt." });
    } catch (e) {
        console.error("Failed to process previous report file", e);
    }
  }

  // 3. Add Prompt
  parts.push({ text: prompt });

  const config: any = {
      model: GEMINI_MODEL,
      contents: {
        role: 'user',
        parts: parts
      },
  };

  if (responseSchema) {
      config.config = {
          responseMimeType: "application/json",
          responseSchema: responseSchema
      };
  }
  
  // Retry logic with exponential backoff
  let retries = 0;
  while (retries < 3) {
      try {
        const response = await ai.models.generateContent(config);
        
        const text = response.text;
        if (!text) throw new Error("Empty response from AI");
        return text;
      } catch (e: any) {
          if (e.message?.includes('429') || e.message?.includes('503')) {
              retries++;
              await new Promise(r => setTimeout(r, 1000 * Math.pow(2, retries))); // 2s, 4s, 8s
          } else {
              throw e;
          }
      }
  }
  throw new Error("Failed to generate content after retries");
};

// --- EXPORTED FUNCTIONS ---

export const generateImageTags = async (photo: Photo): Promise<string[]> => {
    const prompt = `
    Analyze this real estate photo. Return a JSON array of up to 4 short tags describing the room type (e.g., 'Kitchen', 'Bedroom') and key features or defects (e.g., 'Crack', 'Stained Carpet', 'Modern').
    Example: ["Kitchen", "Oven", "Tiled Floor"]
    Only return the JSON array.
    `;
    try {
        const text = await callGemini(prompt, [photo]);
        const cleanText = text.replace(/```json|```/g, '').trim();
        return JSON.parse(cleanText);
    } catch (e) {
        console.warn("Tagging failed", e);
        return [];
    }
};

export const discoverRoomItems = async (roomName: string, photos: Photo[]): Promise<BatchItemResult[]> => {
    const prompt = `
    You are an expert Property Manager creating a Condition Report for a room identified as: "${roomName}".
    
    ${GLOBAL_RULES}

    Task:
    1. Analyze the provided photos of this room.
    2. Identify ALL structural elements, fixtures, and fittings visible (e.g., Walls, Ceiling, Floors, Windows, Blinds, Light Fittings, Power Points, Air Conditioning, Wardrobes, Doors).
    3. For EACH identified item:
       - Assess its condition based on visible evidence.
       - Determine Clean/Undamaged/Working status.
       - Write a concise specific comment.
    
    Output a JSON array of objects:
    [
      {
        "id": "Standard Item Name (e.g. 'Walls', 'Floor')",
        "comment": "Description of condition...",
        "isClean": boolean,
        "isUndamaged": boolean,
        "isWorking": boolean
      }
    ]
    `;

    try {
        const text = await callGemini(prompt, photos);
        const jsonStr = text.replace(/```json|```/g, '').trim();
        const results = JSON.parse(jsonStr);
        return Array.isArray(results) ? results : [];
    } catch (e) {
        console.error("Discovery error", e);
        return [];
    }
};

export const generateOverallComment = async (
    roomName: string, 
    photos: Photo[], 
    currentComment: string,
    previousReportFile?: File,
    previousReportNotes?: string
): Promise<string> => {
    
    const comparisonInstruction = getComparisonContext(previousReportFile, previousReportNotes);

    const prompt = `
    You are an expert Property Manager in Western Australia writing a "Room General Overview" for a Form 1 Condition Report.
    Room: "${roomName}".
    
    ${GLOBAL_RULES}

    ${comparisonInstruction}

    Existing Comment (to refine/append to): "${currentComment}"

    Task:
    1. Analyze the provided photos of this room.
    2. Write or refine a 5-sentence summary paragraph:
       - S1: Overall condition (Excellent/Good/Fair/Poor).
       - S2: Key positive elements (Cleanliness, intact features).
       - S3: Key defects/issues (Scuffs, stains, damage). If none, state "No significant damage observed to visible areas."
       - S4: Functional notes (Lights, windows).
       - S5: Presentation (Tidy/Untidy).
    3. If an existing comment is provided, MERGE the new findings into it. Do not repeat facts. Ensure the final text flows as one cohesive paragraph.
    ${(previousReportFile || previousReportNotes) ? "4. Explicitly mention changes from the previous report if detected." : ""}

    Output: Return ONLY the paragraph text. No JSON.
    `;
    
    return await callGemini(prompt, photos, previousReportFile);
};

export const generateItemComment = async (
    itemName: string, 
    roomName: string, 
    photos: Photo[], 
    currentComment: string,
    previousReportFile?: File,
    previousReportNotes?: string
): Promise<{ comment: string, isClean: boolean, isUndamaged: boolean, isWorking: boolean }> => {
    
    const guidelines = getGuidelinesForItem(itemName);
    
    const comparisonInstruction = getComparisonContext(previousReportFile, previousReportNotes);

    const prompt = `
    You are an expert Property Manager writing a specific item comment for a Form 1 Condition Report.
    Room: "${roomName}"
    Item: "${itemName}"
    
    Specific Inspection Guidelines for this item:
    "${guidelines}"

    ${GLOBAL_RULES}

    ${comparisonInstruction}

    Existing Comment: "${currentComment}"

    Task:
    1. Analyze the photos specifically looking for the item "${itemName}". 
       - If the item is NOT visible in these photos, return the existing comment unchanged (or empty string if none).
    2. Determine the status of three flags based on VISIBLE EVIDENCE:
       - Clean: Free from dirt, dust, mould, grime? (True/False)
       - Undamaged: Free from cracks, chips, swelling, rust? (True/False)
       - Working: visibly functional? (True/False - default to True unless visibly broken or untested mechanical).
    3. Write/Refine a concise comment:
       - Format: "[Item] in [condition] with [defects] located [location]."
       - If existing comment exists, MERGE new details.
       - ${(previousReportFile || previousReportNotes) ? "If comparing, explicitly state 'Compared to previous report: [change/no change]'." : ""}
    
    Output strictly valid JSON:
    {
      "comment": "The text commentary...",
      "isClean": boolean,
      "isUndamaged": boolean,
      "isWorking": boolean
    }
    `;

    try {
        const text = await callGemini(prompt, photos, previousReportFile);
        const jsonStr = text.replace(/```json|```/g, '').trim();
        return JSON.parse(jsonStr);
    } catch (e) {
        console.error("Item generation error", e);
        return { 
            comment: currentComment || "Error analyzing image.", 
            isClean: true, 
            isUndamaged: true, 
            isWorking: true 
        };
    }
};

interface BatchItemResult {
    id: string; // The Name of the item
    comment: string;
    isClean: boolean;
    isUndamaged: boolean;
    isWorking: boolean;
}

interface BatchRoomResult {
    overallComment: string;
    items: BatchItemResult[];
}

export const generateBatchRoomAnalysis = async (
    roomName: string,
    photos: Photo[],
    items: InspectionItem[],
    currentOverallComment: string,
    previousReportFile?: File,
    previousReportNotes?: string
): Promise<BatchRoomResult> => {

    const itemListStr = items.map(i => `- ${i.name} (Current: "${i.comment || 'None'}")`).join('\n');

    const comparisonInstruction = getComparisonContext(previousReportFile, previousReportNotes);

    const prompt = `
    You are an expert Property Manager automating a condition report for: "${roomName}".
    
    ${GLOBAL_RULES}

    ${comparisonInstruction}

    I have a list of items to inspect in this room. 
    Analyze the provided photos. For the Room Overview AND for EACH item in the list, update the status based ONLY on visible evidence in these specific photos.

    Existing Room Overview: "${currentOverallComment}"
    
    Items to Inspect:
    ${itemListStr}

    Task:
    1. Update the 'Room Overview' (Merge new findings with existing text).
    2. For EACH item in the list:
       - Look for the item in the photos.
       - If VISIBLE: Assess Clean/Undamaged/Working flags and write a concise comment merging with the current comment.
       - If NOT VISIBLE: Return the current comment and flags unchanged.
    
    Output strictly valid JSON using this schema:
    {
       "overallComment": "The updated paragraph...",
       "items": [
          {
             "id": "Exact Item Name from list",
             "comment": "Updated comment...",
             "isClean": boolean,
             "isUndamaged": boolean,
             "isWorking": boolean
          }
       ]
    }
    `;

    try {
        const text = await callGemini(prompt, photos, previousReportFile);
        const jsonStr = text.replace(/```json|```/g, '').trim();
        return JSON.parse(jsonStr);
    } catch (e) {
        console.error("Batch generation error", e);
        // Fail gracefully
        return {
            overallComment: currentOverallComment,
            items: []
        };
    }
};