import React from 'react';
import { ReportData, Room } from '../types';

interface PDFPreviewProps {
  data: ReportData;
}

const PDFPreview: React.FC<PDFPreviewProps> = ({ data }) => {
  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('en-AU', {
      weekday: 'long',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  };

  // Helper to get total photo count
  const totalPhotos = data.rooms.reduce((acc, room) => acc + room.photos.length, 0);
  
  // Flatten photos for the appendix
  const allPhotos = data.rooms.flatMap(room => 
    room.photos.map((photo, index) => ({
      ...photo,
      roomName: room.name,
      roomIndex: index + 1,
      totalInRoom: room.photos.length
    }))
  );

  return (
    <div className="bg-white text-black text-sm font-sans leading-tight max-w-[210mm] mx-auto shadow-none print:w-full print:max-w-none">
      
      {/* ------------------- PAGE 1: COVER ------------------- */}
      <div className="p-12 min-h-[297mm] flex flex-col relative page-break box-border">
        {/* Header Logo Section */}
        <div className="flex justify-between items-start mb-12">
          <div className="flex items-center gap-3">
             {/* Logo - Updated to Remote Business Partner style */}
             <div className="w-14 h-14 bg-blue-700 rounded-lg flex items-center justify-center text-white font-bold text-2xl print:print-color-adjust shadow-sm">
                RB
             </div>
             <div className="flex flex-col justify-center h-14">
                <h1 className="text-2xl font-bold text-blue-800 tracking-tight uppercase leading-none" style={{ fontFamily: 'Arial, sans-serif' }}>
                  {data.agentCompany || 'REMOTE BUSINESS PARTNER'}
                </h1>
             </div>
          </div>
          <div className="text-right text-xs font-medium leading-relaxed">
            <p className="font-bold text-black text-sm mb-1">{data.agentCompany || 'Remote Business Partner'}</p>
            {data.agentAddress && <p>{data.agentAddress}</p>}
            {data.agentPhone && <p className="mt-2">T: {data.agentPhone}</p>}
            {data.agentEmail && <p>E: {data.agentEmail}</p>}
          </div>
        </div>

        {/* Title Section */}
        <div className="text-center mt-6 mb-8">
          <h1 className="text-3xl font-bold text-black mb-4" style={{ fontFamily: 'Arial, sans-serif' }}>
            {data.reportType || 'Residential Tenancy Exit Condition Report'}
          </h1>
          <h2 className="text-xl font-bold text-black">
            {data.propertyAddress}
          </h2>
        </div>

        {/* Hero Photo Section */}
        {data.heroPhoto && (
          <div className="flex justify-center mb-8">
            <div className="w-full max-w-[180mm] h-[100mm] border border-gray-300 bg-gray-100 overflow-hidden shadow-sm flex items-center justify-center">
               <img 
                 src={data.heroPhoto.previewUrl} 
                 alt="Property Front" 
                 className="w-full h-full object-cover" 
               />
            </div>
          </div>
        )}

        {/* Footer Details */}
        <div className="mt-auto text-center space-y-4 mb-20">
            <p className="text-sm">Report completed on {formatDate(data.inspectionDate)}</p>
            <p className="text-sm">Prepared by {data.agentName}</p>
        </div>

        <div className="absolute bottom-12 right-12 font-bold text-sm text-blue-800">
            {data.agentCompany || 'Remote Business Partner'}
        </div>
        
        <div className="absolute bottom-4 left-0 right-0 text-center text-[10px] text-gray-500">
            Powered by Inspection Express
        </div>
      </div>

      {/* ------------------- RUNNING HEADER (For subsequent pages) ------------------- */}
      <style>{`
        @media print {
          .running-header {
            position: fixed;
            top: 5mm;
            left: 10mm;
            right: 10mm;
            height: 10mm;
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid black;
            font-size: 10px; /* Reduced font size for header */
            font-style: italic;
            align-items: center;
            background: white;
            z-index: 100;
          }
          .content-start {
            margin-top: 15mm;
          }
          /* Ensure table headers repeat */
          thead { display: table-header-group; }
          tr { page-break-inside: avoid; }
        }
        .running-header { display: none; } /* Hidden on screen, shown in print */
      `}</style>

      {/* Visible Header for Preview Mode only (mimics print header) */}
      <div className="hidden print:flex running-header">
          <span>{data.propertyAddress}</span>
          <span>{data.reportType || 'Exit Condition Report'}</span>
      </div>

      {/* ------------------- CONTENT PAGES ------------------- */}
      <div className="p-10 content-start">
        
        {/* Agent Section Header */}
        <div className="bg-gray-200 border border-black text-center font-bold py-1 mb-1 print:print-color-adjust text-sm">
            Agent section
        </div>
        <div className="text-[10px] mb-4 text-center px-4">
            Each item has been given a column description of 'clean', 'undamaged', 'working'. Tick each column that applies to the item and make any necessary comments.
        </div>

        {/* Rooms */}
        {data.rooms.map((room) => (
          <div key={room.id} className="mb-4">
            <table className="w-full border-collapse border border-black text-[11px]">
              <thead>
                <tr className="bg-gray-100 print:bg-gray-100 print:print-color-adjust">
                  {/* Room Name Header Row */}
                  <th className="border border-black p-1 text-left uppercase font-bold text-sm w-[30%]">
                    {room.name}
                  </th>
                  <th className="border border-black p-1 w-[5%] text-center text-[10px]">Cln</th>
                  <th className="border border-black p-1 w-[5%] text-center text-[10px]">Udg</th>
                  <th className="border border-black p-1 w-[5%] text-center text-[10px]">Wkg</th>
                  <th className="border border-black p-1 text-center font-bold text-xs bg-gray-100 print:print-color-adjust">
                     Agent comments<br/>
                     <span className="text-[9px] font-normal italic">Cln = Clean, Udg = Undamaged, Wkg = Working</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {/* Overall Row - Matches Example Structure */}
                <tr className="border-b border-black">
                    <td className="border-r border-black p-2 align-top">
                        <div className="font-medium">Overall</div>
                    </td>
                    <td className="border-r border-black bg-gray-50"></td>
                    <td className="border-r border-black bg-gray-50"></td>
                    <td className="border-r border-black bg-gray-50"></td>
                    <td className="p-2 align-top text-blue-800 font-medium">
                        {room.photos.length > 0 ? `(${room.photos.length} photos attached)` : ''}
                    </td>
                </tr>
                <tr className="border-b border-black">
                    <td className="border-r border-black p-2 align-top">Overall Commentary</td>
                    <td className="border-r border-black p-1 text-center align-top">Y</td>
                    <td className="border-r border-black p-1 text-center align-top">Y</td>
                    <td className="border-r border-black p-1 text-center align-top">Y</td>
                    <td className="p-2 align-top whitespace-pre-wrap leading-relaxed">
                        {room.overallComment || "No general overview provided."}
                    </td>
                </tr>

                {/* Individual Items */}
                {room.items.map((item) => (
                  <tr key={item.id} className="border-b border-black hover:bg-gray-50">
                    <td className="border-r border-black p-2 align-top text-black">
                        {item.name}
                    </td>
                    <td className="border-r border-black p-1 text-center align-top text-green-700 font-bold">
                        {item.isClean ? 'Y' : 'N'}
                    </td>
                    <td className="border-r border-black p-1 text-center align-top text-green-700 font-bold">
                        {item.isUndamaged ? 'Y' : 'N'}
                    </td>
                    <td className="border-r border-black p-1 text-center align-top text-green-700 font-bold">
                        {item.isWorking ? 'Y' : 'N'}
                    </td>
                    <td className="p-2 align-top text-black">
                        {item.comment ? item.comment : "Refer to Overall Commentary."}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>

      {/* ------------------- SIGNATURES PAGE ------------------- */}
      <div className="p-10 page-break">
         <div className="bg-gray-200 border border-black px-2 py-1 font-bold mb-4 print:print-color-adjust text-sm">
            Special Reporting at Exit Condition Report
         </div>

         <div className="mb-6">
             <h3 className="font-bold text-sm mb-4">Approximate dates when work last done on residential premises</h3>
             
             <div className="space-y-2 text-sm">
                 <div className="flex items-center">
                     <div className="w-1/3">Painting of premises (external):</div>
                     <div className="w-2/3 border border-black h-8 flex items-center justify-center bg-white"> / / </div>
                 </div>
                 <div className="flex items-center">
                     <div className="w-1/3">Painting of premises (internal):</div>
                     <div className="w-2/3 border border-black h-8 flex items-center justify-center bg-white"> / / </div>
                 </div>
                 <div className="flex items-center">
                     <div className="w-1/3">Floorcoverings laid:</div>
                     <div className="w-2/3 border border-black h-8 flex items-center justify-center bg-white"> / / </div>
                 </div>
                 <div className="flex items-center">
                     <div className="w-1/3">Floorcoverings professionally cleaned:</div>
                     <div className="w-2/3 border border-black h-8 flex items-center justify-center bg-white"> / / </div>
                 </div>
             </div>
         </div>

         <div className="mb-8">
             <div className="font-bold text-sm mb-1">Exit Report Additional Comments</div>
             <div className="border border-black h-24 w-full"></div>
         </div>

         <div className="bg-gray-200 border border-black px-2 py-1 font-bold mb-0 print:print-color-adjust text-sm">
            Agent Signature at the END of the Tenancy
         </div>
         <div className="border border-black border-t-0 p-4 flex items-center gap-4 text-sm">
             <div className="flex items-center gap-2">
                 <span>Print Name:</span>
                 <div className="border border-black px-4 py-2 min-w-[200px]">{data.agentName}</div>
             </div>
             <div className="flex items-center gap-2 flex-grow">
                 <span>Signature:</span>
                 <div className="border border-black h-10 flex-grow font-script text-2xl px-2">
                    {/* Simulated Signature */}
                    <span style={{fontFamily: 'cursive'}}>{data.agentName.split(' ')[0]}</span>
                 </div>
             </div>
             <div className="flex items-center gap-2">
                 <span>Date:</span>
                 <div className="border border-black px-4 py-2 min-w-[150px]">{formatDate(data.inspectionDate)}</div>
             </div>
         </div>

         <div className="mt-8 text-[10px] text-justify leading-tight">
             <p className="font-bold mb-1">DISCLAIMER:</p>
             <p>
                This tenancy inspection report is a visual one carried out by us to assess the manner in which the tenant is maintaining your property.
                As your property manager, our role is to manage the tenancy; we are not qualified to assess the structural aspects of areas including
                but not limited to staircases, decking and balconies or to ensure that plumbing, electrical or gas fixtures or fittings, glass windows,
                doors and balustrades, smoke alarms, asbestos, swimming pool safety barriers (and associated fittings) comply and operate in
                accordance with applicable building/council codes and/or laws and regulations. The inspection does not include the moving of furniture,
                lifting of floor coverings, inspecting the interiors of roof spaces, under flooring, inside of cupboards, tenants goods or other belongings.
                It is recommended that all landlords have regular inspections carried out by suitably qualified, licensed and insured contractors and
                experts in the appropriate areas when necessary. It is also recommended that all landlords hold adequate insurance, including
                landlords insurance. To comply with legislation we also recommend landlords outsource the management of smoke alarms to reduce
                the risk and liability in case of a house fire.
             </p>
         </div>
         
         <div className="text-right font-bold text-sm mt-8">
             {data.agentCompany || 'Remote Business Partner'}
         </div>
      </div>

      {/* ------------------- PHOTO APPENDIX ------------------- */}
      {allPhotos.length > 0 && (
        <div className="p-10 page-break">
            <div className="bg-gray-200 border border-black px-2 py-1 font-bold mb-4 print:print-color-adjust text-sm">
                Agent Inspection Photos ({totalPhotos} photos)
            </div>
            
            <div className="grid grid-cols-3 gap-4">
                {allPhotos.map((photo) => (
                    <div key={photo.id} className="mb-4 avoid-break">
                        <div className="text-[10px] font-bold mb-1 uppercase">
                            {photo.roomName}: Overall (photo {photo.roomIndex} of {photo.totalInRoom})
                        </div>
                        <div className="w-full aspect-[4/3] bg-gray-100 border border-gray-300 relative">
                            <img 
                                src={photo.previewUrl} 
                                className="w-full h-full object-cover" 
                                alt={`${photo.roomName} inspection`} 
                            />
                        </div>
                        <div className="text-[9px] text-right text-gray-500 mt-0.5">
                            {/* Simulate Timestamp if not available */}
                            {new Date().toLocaleDateString()}
                        </div>
                    </div>
                ))}
            </div>
        </div>
      )}

    </div>
  );
};

export default PDFPreview;