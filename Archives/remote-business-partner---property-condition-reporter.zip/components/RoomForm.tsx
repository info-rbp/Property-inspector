import React, { useRef, useState, useEffect } from 'react';
import { Room, InspectionItem, Photo, PreviousReportAttachment } from '../types';
import { Trash2, Plus, Sparkles, Loader2, Image as ImageIcon, Check, X, ImageOff, FileWarning, RefreshCw, Wand2, ChevronDown, ChevronUp, Clock, ScanEye, FileText, Upload } from 'lucide-react';
import { generateId, processImageFile } from '../utils';
import { generateItemComment, generateOverallComment, generateImageTags, generateBatchRoomAnalysis, discoverRoomItems } from '../services/geminiService';

interface RoomFormProps {
  room: Room;
  onUpdate: (updatedRoom: Room) => void;
  onDelete: () => void;
  previousReport?: PreviousReportAttachment;
  previousReportNotes?: string;
}

interface QueueItem {
  id: string;
  file: File;
  status: 'pending' | 'processing';
}

// Visual Overlay for AI Generation (Inline)
const AIGeneratingOverlay = ({ mode, message }: { mode: 'create' | 'refine', message?: string }) => (
  <div className="absolute inset-0 bg-white/90 backdrop-blur-[1px] flex flex-col items-center justify-center z-20 rounded border border-purple-100 shadow-inner animate-in fade-in duration-300">
    <div className="flex items-center gap-2 text-purple-700 mb-2">
      {mode === 'refine' ? <RefreshCw size={16} className="text-purple-600 animate-spin" /> : <Sparkles size={16} className="text-purple-600 animate-pulse" />}
      <span className="text-xs font-bold text-purple-900 tracking-wide">
        {mode === 'refine' ? 'AI is building comment...' : 'AI is generating...'}
      </span>
    </div>
    {message && <div className="text-[10px] text-purple-600 font-medium mb-1">{message}</div>}
    <div className="w-1/3 h-1 bg-gray-200 rounded-full overflow-hidden">
       <div className="h-full bg-gradient-to-r from-purple-400 to-purple-600 w-full animate-pulse origin-left"></div>
    </div>
  </div>
);

// Sub-component to handle individual photo states
const PhotoThumbnail: React.FC<{ photo: Photo, isPending?: boolean, showTags?: boolean }> = ({ photo, isPending, showTags }) => {
  const [status, setStatus] = useState<'loading' | 'loaded' | 'error' | 'heic_fallback'>('loading');

  const name = photo.file.name.toLowerCase();
  const isHeic = name.endsWith('.heic') || name.endsWith('.heif') || photo.file.type === 'image/heic' || photo.file.type === 'image/heif';

  useEffect(() => {
    const img = new Image();
    img.src = photo.previewUrl;
    if (isHeic) {
      img.onload = () => setStatus('loaded');
      img.onerror = () => setStatus('heic_fallback');
    } else {
      img.onload = () => setStatus('loaded');
      img.onerror = () => setStatus('error');
    }
    return () => { img.onload = null; img.onerror = null; };
  }, [photo.previewUrl, isHeic]);

  if (status === 'heic_fallback') {
    return (
      <div className={`w-full h-full bg-amber-50 flex flex-col items-center justify-center text-amber-700 p-1 border border-amber-200 rounded select-none animate-pulse ${isPending ? 'opacity-90' : ''}`}>
        <FileWarning size={20} className="mb-1 opacity-75" />
        <span className="text-[9px] font-bold text-center leading-tight">HEIC<br/>(No Preview)</span>
      </div>
    );
  }

  return (
    <div className={`w-full h-full relative bg-gray-50 rounded border ${isPending ? 'border-transparent' : 'border-gray-200'} overflow-hidden group-hover:border-blue-300 transition-colors`}>
      {status === 'loading' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 bg-gray-100 text-blue-400">
          <Loader2 size={20} className="animate-spin mb-1" />
        </div>
      )}
      
      {status === 'error' ? (
        <div className="w-full h-full flex flex-col items-center justify-center text-red-400 p-1 bg-red-50">
           <ImageOff size={20} className="mb-1 opacity-75" />
           <span className="text-[9px] font-bold text-center leading-tight">Load<br/>Error</span>
        </div>
      ) : (
        <>
            <img 
              src={photo.previewUrl} 
              className={`w-full h-full object-cover transition-opacity duration-500 ${status === 'loaded' ? 'opacity-100' : 'opacity-0'}`}
              alt="Thumbnail" 
              loading="lazy"
            />
            {showTags && photo.tags && photo.tags.length > 0 && (
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent pt-4 pb-1 px-1">
                    <div className="flex flex-wrap gap-1 justify-center">
                        {photo.tags.slice(0, 2).map((tag, i) => (
                            <span key={i} className="text-[9px] bg-white/90 text-black px-1 rounded shadow-sm leading-tight max-w-full truncate">
                                {tag}
                            </span>
                        ))}
                    </div>
                </div>
            )}
        </>
      )}
    </div>
  );
};

const RoomForm: React.FC<RoomFormProps> = ({ room, onUpdate, onDelete, previousReport, previousReportNotes }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const processingRef = useRef(false);

  // Loading States
  const [loadingItems, setLoadingItems] = useState<Record<string, string>>({}); // ItemID -> Message
  const [generatingOverall, setGeneratingOverall] = useState<string | null>(null); // Message or null
  const [isBulkGenerating, setIsBulkGenerating] = useState(false);
  const [isDiscovering, setIsDiscovering] = useState(false);
  
  const [isFinalizing, setIsFinalizing] = useState(false);
  const [pendingPhotos, setPendingPhotos] = useState<Photo[]>([]);
  const [processingQueue, setProcessingQueue] = useState<QueueItem[]>([]);
  const [isAutoTagging, setIsAutoTagging] = useState(false);
  
  // Drag and Drop State
  const [isDragging, setIsDragging] = useState(false);

  // Derived processing state
  const isProcessing = processingQueue.length > 0;
  const isBlockingUI = isFinalizing || isProcessing || isAutoTagging || !!generatingOverall || Object.keys(loadingItems).length > 0 || isBulkGenerating || isDiscovering;
  const isExpanded = room.isExpanded !== false; 

  const pendingPhotosRef = useRef<Photo[]>(pendingPhotos);

  useEffect(() => {
    pendingPhotosRef.current = pendingPhotos;
  }, [pendingPhotos]);

  useEffect(() => {
    return () => {
      pendingPhotosRef.current.forEach(p => URL.revokeObjectURL(p.previewUrl));
    };
  }, []);

  // Queue Processor
  useEffect(() => {
    const processQueueBatch = async () => {
      if (processingQueue.length === 0 || processingRef.current) return;
      processingRef.current = true;
      try {
        const BATCH_SIZE = 3;
        const currentBatch = processingQueue.filter(i => i.status === 'pending').slice(0, BATCH_SIZE);
        if (currentBatch.length === 0) {
            processingRef.current = false;
            return;
        }
        setProcessingQueue(prev => prev.map(i => currentBatch.find(b => b.id === i.id) ? { ...i, status: 'processing' } : i));
        await new Promise(resolve => setTimeout(resolve, 20));
        
        const results = await Promise.all(currentBatch.map(async (item) => {
           try {
              const processedFile = await processImageFile(item.file);
              return { id: generateId(), file: processedFile, previewUrl: URL.createObjectURL(processedFile), originalItemId: item.id };
           } catch (err) {
              console.error(`Processing failed for ${item.file.name}`, err);
              return { id: generateId(), file: item.file, previewUrl: URL.createObjectURL(item.file), originalItemId: item.id };
           }
        }));

        setPendingPhotos(prev => [...prev, ...results.map(r => ({ id: r.id, file: r.file, previewUrl: r.previewUrl }))]);
        const processedIds = new Set(results.map(r => r.originalItemId));
        setProcessingQueue(prev => prev.filter(i => !processedIds.has(i.id)));
      } catch (error) {
        console.error("Queue Manager Error:", error);
      } finally {
        processingRef.current = false;
      }
    };
    processQueueBatch();
  }, [processingQueue]);

  const toggleExpand = () => {
    onUpdate({ ...room, isExpanded: !isExpanded });
  };

  const handleAddItem = () => {
    const newItem: InspectionItem = { id: generateId(), name: 'New Item', isClean: true, isUndamaged: true, isWorking: true, comment: '' };
    onUpdate({ ...room, items: [...room.items, newItem] });
  };

  const updateItem = (itemId: string, updates: Partial<InspectionItem>) => {
    const newItems = room.items.map(item => item.id === itemId ? { ...item, ...updates } : item);
    onUpdate({ ...room, items: newItems });
  };

  const deleteItem = (itemId: string) => {
    onUpdate({ ...room, items: room.items.filter(i => i.id !== itemId) });
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const rawFiles = Array.from(e.target.files) as File[];
      const newQueueItems: QueueItem[] = rawFiles.map(f => ({ id: generateId(), file: f, status: 'pending' }));
      setProcessingQueue(prev => [...prev, ...newQueueItems]);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Drag and Drop Handlers
  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragging) setIsDragging(true);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const rawFiles = Array.from(e.dataTransfer.files) as File[];
      const validFiles = rawFiles.filter(f => 
        f.type.startsWith('image/') || 
        f.name.toLowerCase().endsWith('.heic') || 
        f.name.toLowerCase().endsWith('.heif')
      );
      
      if (validFiles.length > 0) {
        const newQueueItems: QueueItem[] = validFiles.map(f => ({ id: generateId(), file: f, status: 'pending' }));
        setProcessingQueue(prev => [...prev, ...newQueueItems]);
      }
    }
  };

  const finalizeUpload = async () => {
    setIsFinalizing(true);
    await new Promise(resolve => setTimeout(resolve, 200));
    const newPhotos = [...pendingPhotos];
    onUpdate({ ...room, photos: [...room.photos, ...newPhotos], status: 'photos_uploaded' });
    setPendingPhotos([]);
    setIsFinalizing(false);
  };

  const cancelUpload = () => {
    pendingPhotos.forEach(p => URL.revokeObjectURL(p.previewUrl));
    setPendingPhotos([]);
    setProcessingQueue([]); 
  };

  const removePendingPhoto = (photoId: string) => {
    const photoToRemove = pendingPhotos.find(p => p.id === photoId);
    if (photoToRemove) URL.revokeObjectURL(photoToRemove.previewUrl);
    setPendingPhotos(prev => prev.filter(p => p.id !== photoId));
  };

  const removePhoto = (photoId: string) => {
    // Memory cleanup: Revoke Object URL to free memory
    const photo = room.photos.find(p => p.id === photoId);
    if (photo) URL.revokeObjectURL(photo.previewUrl);
    
    onUpdate({ ...room, photos: room.photos.filter(p => p.id !== photoId) });
  };

  const handleAutoTag = async () => {
      if (room.photos.length === 0) return;
      setIsAutoTagging(true);
      try {
          const photosToTag = room.photos.filter(p => !p.tags || p.tags.length === 0);
          if (photosToTag.length === 0) {
              if (window.confirm("All photos are already tagged. Re-tag all?")) {
                  let updatedPhotos = [...room.photos];
                  for (let i = 0; i < updatedPhotos.length; i++) {
                      const tags = await generateImageTags(updatedPhotos[i]);
                      updatedPhotos[i] = { ...updatedPhotos[i], tags };
                  }
                  onUpdate({ ...room, photos: updatedPhotos });
              }
          } else {
              let updatedPhotos = [...room.photos];
              for (const photo of photosToTag) {
                  const tags = await generateImageTags(photo);
                  updatedPhotos = updatedPhotos.map(p => p.id === photo.id ? { ...p, tags } : p);
              }
              onUpdate({ ...room, photos: updatedPhotos });
          }
      } catch (e) {
          console.error(e);
          alert("Auto-tagging failed. Check console.");
      } finally {
          setIsAutoTagging(false);
      }
  };

  const handleAutoDetectItems = async () => {
      if (room.photos.length === 0) {
          alert("Please upload photos first so the AI can see the room.");
          return;
      }
      if (isDiscovering) return;

      const confirmMsg = "Ready to detect items from photos?\n\nThis will add ANY visible fixtures (Walls, Windows, Doors, AC, etc.) to your list and automatically comment on them.";
      if (!window.confirm(confirmMsg)) return;

      setIsDiscovering(true);
      setGeneratingOverall("Scanning photos for items...");

      try {
          // Detect Items doesn't utilize previous report, as it's purely identifying presence.
          const discoveredItems = await discoverRoomItems(room.name, room.photos);

          if (discoveredItems.length === 0) {
              alert("No items were confidently detected. Try adding clear photos of the room features.");
              return;
          }

          let addedCount = 0;
          let updatedCount = 0;
          
          const currentItems = [...room.items];
          
          discoveredItems.forEach(newItem => {
             const existingIndex = currentItems.findIndex(
                 i => i.name.toLowerCase() === newItem.id.toLowerCase()
             );

             if (existingIndex > -1) {
                 const ex = currentItems[existingIndex];
                 if (!ex.comment && newItem.comment) {
                     currentItems[existingIndex] = {
                         ...ex,
                         comment: newItem.comment,
                         isClean: newItem.isClean,
                         isUndamaged: newItem.isUndamaged,
                         isWorking: newItem.isWorking
                     };
                     updatedCount++;
                 }
             } else {
                 currentItems.push({
                     id: generateId(),
                     name: newItem.id,
                     comment: newItem.comment || '',
                     isClean: newItem.isClean,
                     isUndamaged: newItem.isUndamaged,
                     isWorking: newItem.isWorking
                 });
                 addedCount++;
             }
          });

          onUpdate({ ...room, items: currentItems });
          setTimeout(() => {
              alert(`Scan Complete!\n\nAdded: ${addedCount} new items\nUpdated: ${updatedCount} existing items`);
          }, 500);

      } catch (e) {
          console.error("Discovery failed", e);
          alert("Failed to discover items. Check API key and quota.");
      } finally {
          setIsDiscovering(false);
          setGeneratingOverall(null);
      }
  };

  const handleBulkGenerate = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (room.photos.length === 0) {
      alert("Please upload photos first.");
      return;
    }
    if (isBulkGenerating) return;

    // Modified confirmation message if comparison is active
    const promptMsg = (previousReport || previousReportNotes)
      ? "Start Bulk Generation with COMPARISON?\n\n• AI will compare photos against the Previous Report/Notes.\n• Differences/damage will be highlighted.\n• All items and overview will be updated.\n\nContinue?"
      : "Start Bulk Auto-Generation?\n\n• This will analyze ALL photos for EVERY item.\n• Existing comments will be refined.\n• Checkboxes will be updated based on visual evidence.\n\nContinue?";

    if (!window.confirm(promptMsg)) return;

    setLoadingItems({});
    setGeneratingOverall(null);
    setIsBulkGenerating(true);

    try {
        let currentRoomState = { ...room };
        
        const syncUpdate = (updates: Partial<Room>) => {
            currentRoomState = { ...currentRoomState, ...updates };
            onUpdate(currentRoomState);
        };

        const CHUNK_SIZE = 5;
        const photos = currentRoomState.photos;

        for (let i = 0; i < photos.length; i += CHUNK_SIZE) {
            const batchPhotos = photos.slice(i, i + CHUNK_SIZE);
            const msg = `Analyzing photo batch ${Math.ceil((i + 1)/CHUNK_SIZE)} of ${Math.ceil(photos.length/CHUNK_SIZE)}...`;
            setGeneratingOverall(msg);

            const analysisResult = await generateBatchRoomAnalysis(
                currentRoomState.name,
                batchPhotos,
                currentRoomState.items,
                currentRoomState.overallComment,
                previousReport?.file, // PASS PREVIOUS REPORT FILE
                previousReportNotes   // PASS PREVIOUS REPORT NOTES
            );

            const newOverall = analysisResult.overallComment || currentRoomState.overallComment;

            const newItems = currentRoomState.items.map(item => {
                const update = analysisResult.items?.find(u => u.id === item.name);
                if (update) {
                    return { ...item, ...update, id: item.id };
                }
                return item;
            });

            syncUpdate({ overallComment: newOverall, items: newItems });
            await new Promise(r => setTimeout(r, 500));
        }

        syncUpdate({ status: 'analyzed' });
        
    } catch (e) {
        console.error("Bulk Generation Critical Failure:", e);
        alert(`Bulk generation was interrupted: ${e instanceof Error ? e.message : 'Unknown Error'}`);
    } finally {
        setIsBulkGenerating(false);
        setGeneratingOverall(null);
        setLoadingItems({});
    }
  };

  const generateAIComment = async (item: InspectionItem) => {
    if (room.photos.length === 0) { alert("Please upload photos first."); return; }
    
    const CHUNK_SIZE = 5;
    const photos = room.photos;
    
    let currentText = item.comment; 

    try {
        for (let i = 0; i < photos.length; i += CHUNK_SIZE) {
            const msg = `Analyzing photos ${i+1}-${Math.min(i+CHUNK_SIZE, photos.length)} of ${photos.length}...`;
            setLoadingItems(prev => ({ ...prev, [item.id]: msg }));

            const batchPhotos = photos.slice(i, i + CHUNK_SIZE);
            
            const result = await generateItemComment(
                item.name, 
                room.name, 
                batchPhotos, 
                currentText,
                previousReport?.file, // PASS PREVIOUS REPORT FILE
                previousReportNotes   // PASS PREVIOUS REPORT NOTES
            );
            
            currentText = result.comment;
            updateItem(item.id, { 
                comment: result.comment,
                isClean: result.isClean,
                isUndamaged: result.isUndamaged,
                isWorking: result.isWorking
            });

            if (i + CHUNK_SIZE < photos.length) {
                await new Promise(r => setTimeout(r, 500)); 
            }
        }
    } catch (err) { 
        alert(`Failed to generate comment: ${err instanceof Error ? err.message : 'Unknown error'}`); 
    } finally { 
        setLoadingItems(prev => { 
            const next = { ...prev }; 
            delete next[item.id]; 
            return next; 
        }); 
    }
  };

  const handleGenerateOverall = async () => {
    if (room.photos.length === 0) { alert("Please upload photos first."); return; }

    const CHUNK_SIZE = 5;
    const photos = room.photos;
    let currentText = room.overallComment;

    try {
        for (let i = 0; i < photos.length; i += CHUNK_SIZE) {
             const msg = `Analyzing photos ${i+1}-${Math.min(i+CHUNK_SIZE, photos.length)} of ${photos.length}...`;
             setGeneratingOverall(msg);

             const batchPhotos = photos.slice(i, i + CHUNK_SIZE);

             const updatedText = await generateOverallComment(
                 room.name,
                 batchPhotos,
                 currentText,
                 previousReport?.file, // PASS PREVIOUS REPORT FILE
                 previousReportNotes   // PASS PREVIOUS REPORT NOTES
             );

             currentText = updatedText;
             onUpdate({ ...room, overallComment: updatedText });

             if (i + CHUNK_SIZE < photos.length) {
                 await new Promise(r => setTimeout(r, 500));
             }
        }
    } catch (err) { 
        alert(`Failed to generate overview: ${err instanceof Error ? err.message : 'Unknown error'}`); 
    } finally { 
        setGeneratingOverall(null); 
    }
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 mb-6 overflow-hidden relative transition-all duration-300 ${!isExpanded ? 'h-auto' : ''}`}>
      
      {/* Header */}
      <div 
        className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center cursor-pointer hover:bg-gray-100 transition-colors select-none"
        onClick={toggleExpand}
      >
        <div className="flex items-center gap-3">
             <div className="text-gray-400">
               {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
             </div>
            <h3 className="text-lg font-semibold text-gray-800">{room.name}</h3>
            <span className="text-xs bg-white border border-gray-200 text-gray-600 px-2 py-1 rounded-full shadow-sm">
                {room.items.length} items
            </span>
            <span className="text-xs bg-white border border-gray-200 text-gray-600 px-2 py-1 rounded-full shadow-sm">
                {room.photos.length} photos
            </span>
        </div>
        
        <button 
            type="button"
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            disabled={isBlockingUI} 
            className="bg-blue-500 hover:bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center shadow transition-all hover:shadow-md disabled:opacity-50"
            title="Delete Area"
        >
          <Trash2 size={16} className="text-white" />
        </button>
      </div>

      {/* Expandable Body */}
      {isExpanded && (
        <div className="p-4 animate-in slide-in-from-top-2 duration-200">
            {/* Photos Section with Drag & Drop */}
            <div 
              className={`mb-6 p-4 rounded-lg border-2 transition-all duration-200 relative ${isDragging ? 'border-blue-500 bg-blue-50 scale-[1.01]' : 'border-transparent'}`}
              onDragEnter={handleDragEnter}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
            
            {/* Overlay for Drop Feedback */}
            {isDragging && (
                <div className="absolute inset-0 z-50 flex items-center justify-center bg-blue-50/90 rounded-lg pointer-events-none">
                    <div className="text-center text-blue-600 animate-in zoom-in-95">
                        <Upload size={48} className="mx-auto mb-2 animate-bounce" />
                        <h3 className="text-lg font-bold">Drop Photos Here</h3>
                        <p className="text-sm opacity-75">Release to add to queue</p>
                    </div>
                </div>
            )}

            <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <ImageIcon size={16}/> Saved Photos
                </h4>
                <div className="flex gap-2">
                    {/* Visual Indicator if Comparison Mode is Ready */}
                    {(previousReport || previousReportNotes) && (
                        <span className="text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded border border-amber-200 flex items-center gap-1 font-bold">
                            <FileText size={12}/> Compare Mode Ready
                        </span>
                    )}
                    <button 
                        type="button"
                        onClick={() => !isProcessing && fileInputRef.current?.click()}
                        disabled={isBlockingUI}
                        className={`text-sm flex items-center gap-1 hover:underline ${isBlockingUI ? 'text-gray-400 cursor-not-allowed' : 'text-blue-600'}`}
                    >
                        {isProcessing ? (
                        <>
                            <Loader2 size={14} className="animate-spin" /> Processing...
                        </>
                        ) : (
                        <>
                            <Plus size={14} /> Select Photos
                        </>
                        )}
                    </button>
                </div>
                <input type="file" multiple accept="image/*,.heic,.heif" className="hidden" ref={fileInputRef} onChange={handleFileSelect}/>
            </div>
            
            {/* Pending Photos Queue UI */}
            {(pendingPhotos.length > 0 || processingQueue.length > 0) && (
                <div className="mb-4 bg-amber-50 border border-amber-200 rounded-lg p-3">
                <div className="flex justify-between items-center mb-2">
                    <h5 className="text-xs font-bold text-amber-800 flex items-center gap-1">
                    <Sparkles size={12} /> {pendingPhotos.length} Photo(s) Ready
                    </h5>
                    <div className="flex gap-2">
                    <button type="button" onClick={cancelUpload} disabled={isBlockingUI} className="text-xs text-red-600 px-2 py-1 flex items-center gap-1 disabled:opacity-50"><X size={12} /> Discard</button>
                    <button type="button" onClick={finalizeUpload} disabled={isBlockingUI} className="bg-green-600 hover:bg-green-700 text-white text-xs font-bold px-3 py-1 rounded shadow-sm flex items-center gap-1 disabled:opacity-75">{isFinalizing ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}{isFinalizing ? 'Saving...' : 'Finalize Upload'}</button>
                    </div>
                </div>
                <div className="flex gap-2 overflow-x-auto pb-2">
                    {pendingPhotos.map(photo => (
                    <div key={photo.id} className="relative flex-shrink-0 w-20 h-20 group border-2 border-amber-400 rounded overflow-hidden bg-white">
                        <PhotoThumbnail photo={photo} isPending={true} />
                        <button type="button" onClick={() => removePendingPhoto(photo.id)} disabled={isBlockingUI} className="absolute top-0 right-0 bg-red-500 text-white p-1 z-30"><Trash2 size={10} /></button>
                    </div>
                    ))}
                    {processingQueue.map(item => (
                    <div key={item.id} className="relative flex-shrink-0 w-20 h-20 bg-white border border-gray-200 rounded flex flex-col items-center justify-center p-2 shadow-sm">
                        <div className="mb-2 text-gray-400">
                           {item.status === 'processing' ? (
                             <Loader2 size={20} className="animate-spin text-blue-500" />
                           ) : (
                             <Clock size={20} />
                           )}
                        </div>
                        
                        <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden mb-1">
                           <div 
                             className={`h-full rounded-full transition-all duration-300 ${item.status === 'processing' ? 'bg-blue-500 w-full animate-pulse' : 'bg-gray-300 w-0'}`}
                           ></div>
                        </div>
                        
                        <span className="text-[8px] text-gray-500 font-medium uppercase tracking-wide">
                            {item.status === 'processing' ? 'Processing' : 'Pending'}
                        </span>
                    </div>
                    ))}
                </div>
                </div>
            )}

            {/* Finalized Photos */}
            {room.photos.length > 0 ? (
                <div className="flex flex-col gap-3">
                <div className="flex gap-2 overflow-x-auto pb-2 min-h-[100px]">
                    {room.photos.map(photo => (
                    <div key={photo.id} className="relative flex-shrink-0 w-24 h-24 group border border-gray-200 rounded bg-gray-50">
                        <PhotoThumbnail photo={photo} showTags={true} />
                        <button type="button" onClick={() => removePhoto(photo.id)} disabled={isBlockingUI} className="absolute top-0 right-0 bg-red-500 text-white p-1 opacity-0 group-hover:opacity-100 transition z-20"><Trash2 size={12} /></button>
                    </div>
                    ))}
                </div>
                {/* Tools Bar */}
                <div className="flex flex-wrap justify-end gap-2 border-t border-gray-100 pt-2">
                    <button 
                        type="button"
                        onClick={handleAutoDetectItems} 
                        disabled={isDiscovering || isBlockingUI}
                        className="flex items-center gap-1 text-xs bg-indigo-50 border border-indigo-200 text-indigo-700 rounded px-3 py-1 hover:bg-indigo-100 disabled:opacity-50 disabled:bg-gray-50 disabled:text-gray-400 cursor-pointer"
                        title="Identify items (Walls, AC, etc) from photos and auto-fill comments"
                    >
                        {isDiscovering ? <Loader2 size={12} className="animate-spin"/> : <ScanEye size={12}/>} 
                        {isDiscovering ? 'Scanning...' : 'Auto-Detect Items from Photos'}
                    </button>
                    <button 
                        type="button"
                        onClick={handleAutoTag} 
                        disabled={isBlockingUI}
                        className="flex items-center gap-1 text-xs border border-gray-300 rounded px-3 py-1 hover:bg-gray-50 disabled:opacity-50"
                    >
                        {isAutoTagging ? <Loader2 size={12} className="animate-spin"/> : <ImageIcon size={12}/>} 
                        {isAutoTagging ? 'Tagging...' : 'Auto-Tag Photos'}
                    </button>
                    <button 
                        type="button"
                        onClick={handleBulkGenerate} 
                        disabled={isBulkGenerating}
                        className="flex items-center gap-1 text-xs bg-purple-50 border border-purple-200 text-purple-700 rounded px-3 py-1 hover:bg-purple-100 disabled:opacity-50 disabled:bg-gray-50 disabled:text-gray-400 cursor-pointer"
                    >
                        {isBulkGenerating ? <Loader2 size={12} className="animate-spin"/> : <Wand2 size={12}/>} 
                        {isBulkGenerating ? 'Generating All...' : 'Bulk Auto-Generate Commentary'}
                    </button>
                </div>
                </div>
            ) : (
                pendingPhotos.length === 0 && processingQueue.length === 0 && (
                    <div onClick={() => !isProcessing && fileInputRef.current?.click()} className="border-2 border-dashed border-gray-300 rounded p-6 text-center cursor-pointer hover:border-blue-400 text-gray-400">
                        <p className="text-sm">Click to select photos (supports HEIC & Standard)</p>
                        <p className="text-xs text-gray-300 mt-1">or Drag & Drop here</p>
                    </div>
                )
            )}
            </div>

            {/* Room Overview */}
            <div className="mb-6 bg-gray-50 p-3 rounded border border-gray-200 relative group/overview">
                <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                        Room General Overview
                        {(previousReport || previousReportNotes) && <span className="text-[10px] bg-amber-100 text-amber-800 px-1 rounded normal-case">Comparing vs Previous Report</span>}
                    </label>
                </div>
                <div className="relative">
                    <textarea
                        value={room.overallComment}
                        onChange={(e) => onUpdate({ ...room, overallComment: e.target.value })}
                        className={`w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-200 focus:border-blue-400 min-h-[60px] ${generatingOverall ? 'text-transparent' : ''}`}
                        placeholder="General comments..."
                        disabled={isBlockingUI}
                    />
                    {generatingOverall ? <AIGeneratingOverlay mode={room.overallComment ? 'refine' : 'create'} message={generatingOverall} /> : (
                        <button 
                            type="button" 
                            onClick={handleGenerateOverall} 
                            disabled={isBlockingUI} 
                            className="absolute top-2 right-2 text-purple-600 bg-purple-50 p-1 rounded-full opacity-0 group-hover/overview:opacity-100 transition border border-purple-200 flex items-center gap-1 pr-2 hover:bg-purple-100"
                            title={room.overallComment ? "Refine / Update Comment" : "Generate Comment"}
                        >
                            {room.overallComment ? <RefreshCw size={14} /> : <Sparkles size={14} />}
                            {room.overallComment && <span className="text-[10px] font-bold">Refine</span>}
                        </button>
                    )}
                </div>
            </div>

            {/* Items List */}
            <div className="space-y-3">
            {room.items.map((item) => (
                <div key={item.id} className="grid grid-cols-12 gap-4 items-start bg-gray-50 p-2 rounded hover:bg-gray-100 transition">
                <div className="col-span-3">
                    <input type="text" value={item.name} onChange={(e) => updateItem(item.id, { name: e.target.value })} className="w-full bg-transparent border-b border-transparent focus:border-blue-500 focus:outline-none text-sm font-medium" disabled={isBlockingUI} />
                </div>
                <div className="col-span-2 flex justify-between px-2 pt-1">
                    <input type="checkbox" checked={item.isClean} onChange={(e) => updateItem(item.id, { isClean: e.target.checked })} className="accent-green-600 w-4 h-4" disabled={isBlockingUI} />
                    <input type="checkbox" checked={item.isUndamaged} onChange={(e) => updateItem(item.id, { isUndamaged: e.target.checked })} className="accent-green-600 w-4 h-4" disabled={isBlockingUI} />
                    <input type="checkbox" checked={item.isWorking} onChange={(e) => updateItem(item.id, { isWorking: e.target.checked })} className="accent-green-600 w-4 h-4" disabled={isBlockingUI} />
                </div>
                <div className="col-span-6 relative group/comment">
                    <textarea value={item.comment} onChange={(e) => updateItem(item.id, { comment: e.target.value })} className={`w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-200 focus:border-blue-400 min-h-[60px] ${loadingItems[item.id] ? 'text-transparent' : ''}`} placeholder="Condition..." disabled={isBlockingUI} />
                    {loadingItems[item.id] ? <AIGeneratingOverlay mode={item.comment ? 'refine' : 'create'} message={loadingItems[item.id]} /> : (
                        <button 
                            type="button" 
                            onClick={() => generateAIComment(item)} 
                            disabled={isBlockingUI} 
                            className="absolute top-2 right-2 text-purple-600 bg-purple-50 p-1 rounded-full opacity-0 group-hover/comment:opacity-100 transition border border-purple-200 flex items-center gap-1 pr-2 hover:bg-purple-100"
                            title={item.comment ? "Refine / Update Comment" : "Generate Comment"}
                        >
                            {item.comment ? <RefreshCw size={14} /> : <Sparkles size={14} />}
                            {item.comment && <span className="text-[10px] font-bold">Refine</span>}
                        </button>
                    )}
                </div>
                <div className="col-span-1 flex justify-end">
                    <button type="button" onClick={() => deleteItem(item.id)} disabled={isBlockingUI} className="text-gray-400 hover:text-red-500 pt-2"><Trash2 size={16} /></button>
                </div>
                </div>
            ))}
            </div>
            
            <div className="flex justify-between items-center mt-6">
                <button type="button" onClick={handleAddItem} disabled={isBlockingUI} className="flex items-center gap-2 text-sm font-medium text-blue-600 hover:text-blue-700 disabled:opacity-50">
                    <Plus size={16} /> Add Item
                </button>
            </div>
        </div>
      )}
    </div>
  );
};

export default RoomForm;