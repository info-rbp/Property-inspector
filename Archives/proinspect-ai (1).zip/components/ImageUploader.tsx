import React, { ChangeEvent, useRef, useState, DragEvent } from 'react';
import { Upload, X, Image as ImageIcon, Video, Loader2 } from 'lucide-react';

interface ImageUploaderProps {
  files: File[];
  onFilesChange: (files: File[]) => void;
  disabled?: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ files, onFilesChange, disabled }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      onFilesChange([...files, ...newFiles]);
    }
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (disabled) return;
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled) return;

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFiles = Array.from(e.dataTransfer.files) as File[];
      const validFiles = droppedFiles.filter(file => 
        file.type.startsWith('image/') || file.type.startsWith('video/')
      );
      
      if (validFiles.length > 0) {
        onFilesChange([...files, ...validFiles]);
      }
    }
  };

  const removeFile = (index: number) => {
    const updatedFiles = files.filter((_, i) => i !== index);
    onFilesChange(updatedFiles);
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full space-y-4">
      <div 
        onClick={!disabled ? triggerFileInput : undefined}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer relative
          ${disabled 
            ? 'opacity-50 cursor-not-allowed bg-gray-100 border-gray-300' 
            : isDragging 
              ? 'border-blue-500 bg-blue-100 ring-4 ring-blue-500/20 scale-[1.01]' 
              : 'border-blue-300 bg-blue-50/50 hover:bg-blue-50 hover:border-blue-500'
          }
        `}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*,video/*"
          multiple
          className="hidden"
          disabled={disabled}
        />
        <div className="flex flex-col items-center justify-center space-y-2 text-gray-500">
          <div className={`p-3 bg-white rounded-full shadow-sm transition-transform ${isDragging ? 'scale-110 duration-200' : ''}`}>
            <div className="flex gap-1">
              <Upload className={`w-6 h-6 ${isDragging ? 'text-blue-700' : 'text-blue-600'}`} />
            </div>
          </div>
          <p className="font-medium text-gray-700">
            {isDragging ? 'Drop files here' : 'Click or drag & drop to upload'}
          </p>
          <p className="text-sm text-gray-400">Supported: Images (JPG, PNG) & Short Videos</p>
        </div>
      </div>

      {files.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {files.map((file, index) => (
            <div key={`${file.name}-${index}`} className="relative group aspect-square rounded-lg overflow-hidden border border-gray-200 shadow-sm bg-gray-100">
              {file.type.startsWith('video/') ? (
                <div className="w-full h-full flex items-center justify-center relative">
                   <video 
                     src={URL.createObjectURL(file)} 
                     className="w-full h-full object-cover" 
                     muted 
                     onMouseOver={e => e.currentTarget.play()}
                     onMouseOut={e => e.currentTarget.pause()}
                   />
                   <div className="absolute top-2 left-2 bg-black/50 p-1 rounded z-10">
                     <Video className="w-4 h-4 text-white" />
                   </div>
                </div>
              ) : (
                <img
                  src={URL.createObjectURL(file)}
                  alt={`preview-${index}`}
                  className="w-full h-full object-cover"
                />
              )}
              
              {disabled && (
                 <div className="absolute inset-0 z-20 bg-black/40 backdrop-blur-[1px] flex items-center justify-center transition-all duration-300 animate-in fade-in">
                    <div className="flex flex-col items-center p-2 rounded-lg">
                      <Loader2 className="w-8 h-8 text-white animate-spin drop-shadow-md mb-2" />
                      <div className="h-1 w-16 bg-white/30 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 animate-[loading_1.5s_ease-in-out_infinite] w-full origin-left" />
                      </div>
                    </div>
                 </div>
              )}

              {!disabled && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    removeFile(index);
                  }}
                  className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg z-10 hover:bg-red-600"
                  title="Remove file"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-1.5 text-xs text-white truncate px-2 z-10">
                {file.name}
              </div>
            </div>
          ))}
        </div>
      )}
      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          50% { transform: translateX(0%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

export default ImageUploader;