import React, { useState } from 'react';
import { RoomType, InspectionReport, AnalysisMode, AspectRatio } from './types';
import { analyzeInspectionImages, generateReferenceImage } from './services/geminiService';
import ImageUploader from './components/ImageUploader';
import RoomSelector from './components/RoomSelector';
import { ReportView } from './components/ReportView';
import { ClipboardCheck, Loader2, ArrowRight, RefreshCw, AlertCircle, Wand2, Settings2, ImagePlus } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'inspect' | 'visualize'>('inspect');
  
  // Inspection State
  const [files, setFiles] = useState<File[]>([]);
  const [roomType, setRoomType] = useState<RoomType>(RoomType.LivingRoom);
  const [analysisMode, setAnalysisMode] = useState<AnalysisMode>(AnalysisMode.Standard);
  const [loading, setLoading] = useState<boolean>(false);
  const [report, setReport] = useState<InspectionReport | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Visualizer State
  const [genPrompt, setGenPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [genLoading, setGenLoading] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);

  const handleReset = () => {
    setFiles([]);
    setReport(null);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (files.length === 0) return;

    setLoading(true);
    setError(null);
    
    try {
      const result = await analyzeInspectionImages(files, roomType, analysisMode);
      setReport(result);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to analyze images. Please check your API key and try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!genPrompt.trim()) return;
    setGenLoading(true);
    setGenError(null);
    try {
      const base64 = await generateReferenceImage(genPrompt, aspectRatio);
      setGeneratedImage(base64);
    } catch (err: any) {
      setGenError(err.message || "Failed to generate image.");
    } finally {
      setGenLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="p-2 bg-blue-600 rounded-lg shadow-lg shadow-blue-600/20 mr-3">
                 <ClipboardCheck className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 tracking-tight">ProInspect AI</h1>
                <p className="text-xs text-gray-500 font-medium hidden sm:block">Intelligent Property Condition Assessment</p>
              </div>
            </div>
            
            {/* Tabs */}
            <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
               <button 
                 onClick={() => setActiveTab('inspect')}
                 className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${activeTab === 'inspect' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
               >
                 Inspection
               </button>
               <button 
                 onClick={() => setActiveTab('visualize')}
                 className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${activeTab === 'visualize' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
               >
                 Visualizer
               </button>
            </div>

            {report && activeTab === 'inspect' && (
              <button
                onClick={handleReset}
                className="ml-4 text-sm font-medium text-gray-600 hover:text-blue-600 flex items-center px-3 py-2 rounded-md hover:bg-gray-100 transition-colors"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                New Inspection
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* INSPECTION TAB */}
        {activeTab === 'inspect' && (
          <>
            {error && (
              <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start text-red-700 animate-in slide-in-from-top-2">
                <AlertCircle className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold">Analysis Failed</h3>
                  <p className="text-sm opacity-90">{error}</p>
                </div>
              </div>
            )}

            {!report ? (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                
                <div className="text-center max-w-2xl mx-auto mb-10">
                   <h2 className="text-3xl font-bold text-gray-900 mb-4">Upload property photos or videos</h2>
                   <p className="text-gray-600">
                     Our AI identifies components, detects damage, and generates professional condition reports in seconds.
                   </p>
                </div>

                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                  <div className="p-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 opacity-80" />
                  <div className="p-6 md:p-8 space-y-8">
                    
                    {/* Mode Selector */}
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-sm">1</span>
                        <h3 className="text-lg font-semibold text-gray-900">Analysis Mode</h3>
                      </div>
                      <div className="pl-11 max-w-md">
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            {Object.values(AnalysisMode).map((mode) => (
                              <div 
                                key={mode}
                                onClick={() => !loading && setAnalysisMode(mode)}
                                className={`
                                  cursor-pointer rounded-lg border p-3 flex flex-col justify-between transition-all
                                  ${analysisMode === mode ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'border-gray-200 hover:border-gray-300'}
                                  ${loading ? 'opacity-50 cursor-not-allowed' : ''}
                                `}
                              >
                                <span className="text-sm font-medium text-gray-900">{mode}</span>
                                {mode.includes('Fast') && <span className="text-xs text-gray-500 mt-1">For speed</span>}
                                {mode.includes('Standard') && <span className="text-xs text-gray-500 mt-1">Balanced</span>}
                                {mode.includes('Deep') && <span className="text-xs text-gray-500 mt-1">Thinking Model</span>}
                              </div>
                            ))}
                         </div>
                      </div>
                    </div>

                    {/* Room Type */}
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-sm">2</span>
                        <h3 className="text-lg font-semibold text-gray-900">Room Type</h3>
                      </div>
                      <div className="pl-11 max-w-md">
                        <RoomSelector 
                          selectedRoom={roomType} 
                          onChange={setRoomType} 
                          disabled={loading}
                        />
                      </div>
                    </div>

                    {/* Upload */}
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-sm">3</span>
                        <h3 className="text-lg font-semibold text-gray-900">Upload Media</h3>
                      </div>
                      <div className="pl-11">
                        <ImageUploader 
                          files={files} 
                          onFilesChange={setFiles} 
                          disabled={loading}
                        />
                        <p className="text-xs text-gray-400 mt-2">
                          Tip: Include a wide context shot and close-ups. Video walk-throughs supported in Deep Mode.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end">
                    <button
                      onClick={handleAnalyze}
                      disabled={loading || files.length === 0}
                      className={`
                        flex items-center px-6 py-3 rounded-lg font-semibold text-white shadow-md transition-all
                        ${loading || files.length === 0 
                          ? 'bg-gray-400 cursor-not-allowed' 
                          : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 hover:shadow-lg active:scale-95'}
                      `}
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          Generate Inspection Report
                          <ArrowRight className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <ReportView report={report} />
            )}
          </>
        )}

        {/* VISUALIZER TAB */}
        {activeTab === 'visualize' && (
           <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="text-center max-w-2xl mx-auto mb-10">
                 <h2 className="text-3xl font-bold text-gray-900 mb-4">Generate Reference Images</h2>
                 <p className="text-gray-600">
                   Visualize repairs, renovations, or ideal states using our advanced image generation model.
                 </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                 {/* Controls */}
                 <div className="lg:col-span-1 space-y-6">
                    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                       <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                         <Settings2 className="w-5 h-5 mr-2 text-gray-500" />
                         Configuration
                       </h3>
                       
                       <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Aspect Ratio</label>
                            <select 
                              value={aspectRatio}
                              onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            >
                              <option value="1:1">1:1 (Square)</option>
                              <option value="5:4">5:4 (Print)</option>
                              <option value="4:5">4:5 (Print Portrait)</option>
                              <option value="4:3">4:3 (Standard)</option>
                              <option value="3:4">3:4 (Portrait)</option>
                              <option value="3:2">3:2 (Landscape)</option>
                              <option value="2:3">2:3 (Portrait)</option>
                              <option value="16:10">16:10 (Screen)</option>
                              <option value="16:9">16:9 (Widescreen)</option>
                              <option value="9:16">9:16 (Story)</option>
                              <option value="21:9">21:9 (Cinematic)</option>
                            </select>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Prompt</label>
                            <textarea
                              rows={5}
                              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                              placeholder="Describe the room or repair you want to visualize..."
                              value={genPrompt}
                              onChange={(e) => setGenPrompt(e.target.value)}
                            />
                          </div>

                          <button
                            onClick={handleGenerateImage}
                            disabled={genLoading || !genPrompt}
                            className={`
                              w-full flex items-center justify-center px-4 py-2.5 rounded-lg font-semibold text-white shadow-sm transition-all
                              ${genLoading || !genPrompt
                                ? 'bg-gray-400 cursor-not-allowed' 
                                : 'bg-blue-600 hover:bg-blue-700 hover:shadow-md'}
                            `}
                          >
                             {genLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Wand2 className="w-5 h-5 mr-2" /> Generate</>}
                          </button>
                       </div>
                    </div>
                    {genError && (
                      <div className="p-4 bg-red-50 text-red-700 text-sm rounded-lg border border-red-200">
                        {genError}
                      </div>
                    )}
                 </div>

                 {/* Preview */}
                 <div className="lg:col-span-2">
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden min-h-[400px] flex items-center justify-center bg-gray-50/50">
                       {generatedImage ? (
                         <div className="relative w-full h-full p-4">
                            <img src={generatedImage} alt="Generated" className="w-full h-auto rounded-lg shadow-sm" />
                            <a 
                              href={generatedImage} 
                              download="generated-inspection-ref.png"
                              className="absolute top-6 right-6 bg-white/90 p-2 rounded-full shadow-md hover:bg-white text-gray-700 hover:text-blue-600"
                              title="Download"
                            >
                              <ImagePlus className="w-5 h-5" />
                            </a>
                         </div>
                       ) : (
                         <div className="text-center text-gray-400">
                            <ImagePlus className="w-16 h-16 mx-auto mb-4 opacity-20" />
                            <p>Generated image will appear here</p>
                         </div>
                       )}
                    </div>
                 </div>
              </div>
           </div>
        )}

      </main>
    </div>
  );
};

export default App;