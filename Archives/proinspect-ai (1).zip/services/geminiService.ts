import { GoogleGenAI } from "@google/genai";
import { InspectionReport, AnalysisMode, AspectRatio } from "../types";

const SYSTEM_INSTRUCTION = `
You are an expert property inspection assistant used in a professional real estate condition reporting system.

You must analyze inspection photos of a single room and return structured, factual, conservative assessments suitable for tenancy documentation. You must not guess. If the photo does not clearly show something, say so.

GOAL
- Identify visible components in the room (only what is clearly visible)
- Assess cleanliness and damage conservatively
- Detect visible defects (if present) using a fixed taxonomy
- Write short, professional inspection comments
- Output STRICT JSON only, matching the schema below

IMPORTANT RULES (NON-NEGOTIABLE)
1) Do NOT assume damage from shadows, reflections, glare, low light, blur, or clutter.
2) Close-up images override wide shots for damage severity and cleanliness.
3) If visibility is insufficient, do not mark as undamaged/clean with confidence. Use needsConfirmation=true on issues and explain why.
4) Do not output markdown. Do not output explanations. JSON only.

ROOM COMPONENT LISTS
Only include components clearly visible in the images. Use these as the default component set per room type:

Kitchen: ceiling, walls, floor, skirting, doors/frames, windows/frames, cabinetry, benchtops, splashback, sink/tap, cooktop/oven area, rangehood, lighting visible
Bathroom: ceiling, walls, floor, skirting, doors/frames, windows/frames, shower area, vanity/basin, mirror, toilet, tiles/grout, exhaust fan visible, towel rails visible
Bedroom: ceiling, walls, floor, skirting, doors/frames, windows/frames, wardrobe/closet doors visible, lighting visible
Living/Dining: ceiling, walls, floor, skirting, doors/frames, windows/frames, curtains/blinds visible, lighting visible
Laundry: ceiling, walls, floor, skirting, tub/sink, cabinetry visible, taps/hoses visible, ventilation visible
Hallway: ceiling, walls, floor, skirting, doors/frames, lighting visible
Outdoor/Balcony: floor surface, balustrade/railings, walls, doors, drains visible, ceiling/soffit visible
Garage: floor, walls, doors, ceiling, shelving visible

DEFECT TAXONOMY (ISSUE TYPES)
Use ONLY these issue types (do not invent new types):
- stain
- water_damage
- mold_mildew
- crack
- hole
- scuff_mark
- paint_damage
- chip_dent
- broken_item
- heavy_wear
- dirt_grime
- rust_corrosion

SEVERITY RUBRIC
- minor: small/localized, cosmetic, limited area
- moderate: clearly visible, affects notable area or multiple spots
- major: extensive, severe, structural-looking, or clearly requiring repair

CONDITION FLAGS DEFINITION
For each component:
- isClean: appears free from visible dirt, residue, stains, grime
- isUndamaged: no visible physical damage (cracks/holes/chips/breakage/etc)
- isWorking: only for functional/mechanical items IF visible evidence supports it. If cannot be verified from image, omit isWorking or set it cautiously and explain.

CONFIDENCE AND UNCERTAINTY
- confidence is 0.0 to 1.0 for each issue
- if confidence < 0.6 => needsConfirmation=true
- if you are unsure due to lighting/angle/obstruction, say so in notes/comment

COMMENT CONSTRUCTION RULES
The "overallComment" and component "comment" fields must:
- Be 2–3 sentences in total
- Summarise the overall condition of the item
- Explicitly mention:
  • the most severe issue first
  • any secondary issues
  • whether the issue appears localized or affects multiple areas
- Use neutral inspection language
- Avoid recommendations, causes, or repair advice
- Do NOT restate confidence values or issue labels

Structure the comments as:
Sentence 1: Overall condition and primary defect (severity included)
Sentence 2: Secondary defects and extent
Sentence 3 (optional): Cleanliness or general condition context

GUARDRAILS
The comments must NOT:
- Recommend repairs
- Suggest causes
- Assign responsibility
- Mention safety risks
- Use emotive or speculative language

SEVERITY EMPHASIS
If any issue has severity "major":
- The comment must include at least 2 sentences
- The major issue must be described in the first sentence

OUTPUT FORMAT (STRICT JSON ONLY)
Return only valid JSON in this structure:

{
  "roomType": "string",
  "overallComment": "string",
  "components": [
    {
      "name": "string",
      "condition": {
        "isClean": true,
        "isUndamaged": true,
        "isWorking": true
      },
      "issues": [
        {
          "type": "stain | water_damage | mold_mildew | crack | hole | scuff_mark | paint_damage | chip_dent | broken_item | heavy_wear | dirt_grime | rust_corrosion",
          "severity": "minor | moderate | major",
          "confidence": 0.0,
          "notes": "string",
          "needsConfirmation": false
        }
      ],
      "comment": "string"
    }
  ]
}

STYLE
- Neutral, professional inspection language
- Short, factual sentences
- No exaggeration
- No legal conclusions

If there are no issues for a component, return "issues": [] and still include a brief component comment.

EXAMPLE
Input: Bathroom images showing minor ceiling staining near corner.
Output JSON should say:
- ceiling: issue type=stain, severity=minor, confidence ~0.7
- notes mention lighting limits if applicable
- overallComment short and factual
`;

const MAX_IMAGE_DIMENSION = 1536;
const JPEG_QUALITY = 0.8;

const compressImage = async (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      
      let width = img.width;
      let height = img.height;
      
      // Calculate new dimensions to fit within MAX_IMAGE_DIMENSION
      if (width > height) {
        if (width > MAX_IMAGE_DIMENSION) {
          height = Math.round(height * (MAX_IMAGE_DIMENSION / width));
          width = MAX_IMAGE_DIMENSION;
        }
      } else {
        if (height > MAX_IMAGE_DIMENSION) {
          width = Math.round(width * (MAX_IMAGE_DIMENSION / height));
          height = MAX_IMAGE_DIMENSION;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error("Could not get canvas context"));
        return;
      }
      
      // High quality smoothing
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      
      ctx.drawImage(img, 0, 0, width, height);
      
      // Get base64 string
      const dataUrl = canvas.toDataURL('image/jpeg', JPEG_QUALITY);
      // Remove prefix "data:image/jpeg;base64,"
      const base64Content = dataUrl.split(',')[1];
      resolve(base64Content);
    };
    
    img.onerror = (error) => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("Failed to load image for processing"));
    };
    
    img.src = objectUrl;
  });
};

const readFileAsBase64 = async (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  try {
    if (file.type.startsWith('video/')) {
      // For video, we pass the raw base64. 
      // Note: Large videos should use File API, but for this demo we assume reasonable size < 20MB
      const base64Content = await readFileAsBase64(file);
      return {
        inlineData: {
          data: base64Content,
          mimeType: file.type,
        },
      };
    } else {
      // For images, compress them
      const base64Content = await compressImage(file);
      return {
        inlineData: {
          data: base64Content,
          mimeType: "image/jpeg",
        },
      };
    }
  } catch (error) {
    console.error("Error processing file:", error);
    throw error;
  }
};

export const analyzeInspectionImages = async (
  files: File[],
  roomType: string,
  mode: AnalysisMode
): Promise<InspectionReport> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set REACT_APP_GEMINI_API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Determine model and config based on mode and content
  let modelName = 'gemini-2.5-flash';
  let config: any = {
    systemInstruction: SYSTEM_INSTRUCTION,
    responseMimeType: "application/json",
    temperature: 0.2,
  };

  const hasVideo = files.some(f => f.type.startsWith('video/'));

  if (hasVideo) {
    // Requirement: Video understanding must use gemini-3-pro-preview
    modelName = 'gemini-3-pro-preview';
    // Deep analysis for video is usually good
    config.temperature = 0.2;
  } else {
    switch (mode) {
      case AnalysisMode.Fast:
        // Requirement: Low-latency responses using gemini-2.5-flash-lite
        modelName = 'gemini-2.5-flash-lite-latest'; // using common alias for lite
        break;
      case AnalysisMode.Deep:
        // Requirement: Think more when needed using gemini-3-pro-preview + thinkingBudget
        modelName = 'gemini-3-pro-preview';
        config = {
          ...config,
          thinkingConfig: { thinkingBudget: 32768 }, // Max for Pro
        };
        // Note: responseMimeType is NOT supported with Thinking Mode in some versions, 
        // but let's try keeping it or remove if it fails. 
        // Best practice for Thinking is often to let it think then output.
        // However, the prompt requires JSON. Gemini 2.5/3 usually supports JSON + Thinking.
        // If strict JSON mode conflicts, we might need to rely on the prompt.
        // Let's keep responseMimeType as it ensures the app doesn't break.
        break;
      case AnalysisMode.Standard:
      default:
        modelName = 'gemini-2.5-flash';
        break;
    }
  }

  try {
    const parts = await Promise.all(files.map(fileToGenerativePart));
    
    // Improved prompt structure with better context
    const prompt = `
Room type: ${roomType}
Inspection type: Routine
Media notes:
${files.map((f, i) => `- Image ${i+1}: ${f.name}`).join('\n')}

Task:
Analyze all images together as one room. Use close-ups as primary evidence for issues.
Return strict JSON only.
`;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        role: "user",
        parts: [
          ...parts,
          { text: prompt }
        ]
      },
      config: config,
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response received from Gemini.");
    }

    try {
      // Clean up markdown code blocks if present (common with Thinking models)
      const jsonString = text.replace(/```json\n|\n```/g, "").trim();
      const parsedData = JSON.parse(jsonString) as InspectionReport;
      return parsedData;
    } catch (parseError) {
      console.error("JSON Parse Error:", parseError, text);
      throw new Error("Failed to parse inspection report JSON.");
    }
  } catch (error) {
    console.error("Inspection Analysis Error:", error);
    throw error;
  }
};

export const generateReferenceImage = async (
  prompt: string,
  aspectRatio: AspectRatio
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    // Requirement: Image generation using gemini-3-pro-image-preview
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
          imageSize: "1K", 
        }
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image generated.");
  } catch (error) {
    console.error("Image Generation Error:", error);
    throw error;
  }
};
