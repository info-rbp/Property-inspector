
export interface Issue {
  type: string;
  severity: 'minor' | 'moderate' | 'major';
  confidence: number;
  notes: string;
  needsConfirmation: boolean;
}

export interface ComponentCondition {
  isClean: boolean;
  isUndamaged: boolean;
  isWorking?: boolean; // Optional as not all components are mechanical
}

export interface Component {
  name: string;
  condition: ComponentCondition;
  issues: Issue[];
  comment: string;
}

export interface InspectionReport {
  roomType: string;
  overallComment: string;
  components: Component[];
}

export enum RoomType {
  Kitchen = 'Kitchen',
  Bathroom = 'Bathroom',
  LivingRoom = 'Living Room',
  Bedroom = 'Bedroom',
  DiningRoom = 'Dining Room',
  Hallway = 'Hallway',
  Laundry = 'Laundry',
  Outdoor = 'Outdoor / Balcony',
  Garage = 'Garage',
  Other = 'Other'
}

export enum AnalysisMode {
  Fast = 'Fast (Flash Lite)',
  Standard = 'Standard (Flash)',
  Deep = 'Deep Analysis (Pro + Thinking)'
}

export type AspectRatio = '1:1' | '2:3' | '3:2' | '3:4' | '4:3' | '5:4' | '4:5' | '9:16' | '16:9' | '16:10' | '21:9';
