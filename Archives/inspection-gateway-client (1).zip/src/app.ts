import Fastify from 'fastify';
import { serializerCompiler, validatorCompiler } from 'fastify-type-provider-zod';
import { diagnosticsRoutes } from './routes/diagnostics';
import { inspectionRoutes } from './routes/inspections';
import { orchestrationRoutes } from './routes/orchestration';
import { webhookRoutes } from './routes/webhooks';

export function buildApp() {
  const app = Fastify({
    logger: true
  });

  // Zod Integration
  app.setValidatorCompiler(validatorCompiler);
  app.setSerializerCompiler(serializerCompiler);

  // Global Error Handler
  app.setErrorHandler((error, request, reply) => {
    app.log.error(error);
    reply.status(500).send({ error: 'Internal Server Error', message: error.message });
  });

  // Routes
  app.register(diagnosticsRoutes);
  app.register(inspectionRoutes);
  app.register(orchestrationRoutes);
  app.register(webhookRoutes);

  return app;
}