import { FastifyReply, FastifyRequest } from 'fastify';
import jwt from 'jsonwebtoken';
import jwksClient from 'jwks-rsa';
import { env } from '../config/env';

const client = jwksClient({
  jwksUri: env.JWT_JWKS_URL,
  cache: true,
  rateLimit: true,
});

function getKey(header: any, callback: any) {
  client.getSigningKey(header.kid, function (err, key) {
    const signingKey = key?.getPublicKey();
    callback(err, signingKey);
  });
}

export interface UserContext {
  userId: string;
  tenantId: string;
  role: 'ADMIN' | 'INSPECTOR' | 'VIEWER';
}

export const verifyJwt = (req: FastifyRequest, reply: FastifyReply, done: (err?: Error) => void) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return reply.status(401).send({ error: 'Missing Authorization header' });
  }

  const token = authHeader.split(' ')[1];
  jwt.verify(token, getKey, { algorithms: ['RS256'] }, (err, decoded: any) => {
    if (err) {
      return reply.status(401).send({ error: 'Invalid Token' });
    }

    // Tenant and Role extraction - adjust based on actual Identity Provider claims
    const tenantId = decoded.tenant_id || decoded.custom_claims?.tenantId;
    const role = decoded.role || decoded.custom_claims?.role || 'VIEWER';

    if (!tenantId) {
      return reply.status(403).send({ error: 'Token missing tenant context' });
    }

    (req as any).user = {
      userId: decoded.sub as string,
      tenantId,
      role
    };
    done();
  });
};

export const requireRole = (roles: string[]) => {
  return async (req: FastifyRequest, reply: FastifyReply) => {
    const user = (req as any).user as UserContext;
    if (!roles.includes(user.role)) {
      return reply.status(403).send({ error: 'Insufficient Permissions' });
    }
  };
};