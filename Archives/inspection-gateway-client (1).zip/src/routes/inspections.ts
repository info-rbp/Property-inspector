import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../db/client';
import { verifyJwt, requireRole, UserContext } from '../middleware/auth';
import { InspectionStatus, InspectionType } from '@prisma/client';

export async function inspectionRoutes(app: FastifyInstance) {
  app.addHook('preHandler', verifyJwt);

  // GET /v1/inspections (Paged)
  app.get('/v1/inspections', async (req, reply) => {
    const user = (req as any).user as UserContext;
    const inspections = await prisma.inspection.findMany({
      where: { tenantId: user.tenantId },
      orderBy: { updatedAt: 'desc' },
      take: 20 // Simple pagination limit
    });
    return inspections;
  });

  // POST /v1/inspections
  app.post('/v1/inspections', {
    preHandler: requireRole(['ADMIN', 'INSPECTOR']),
    schema: {
      body: z.object({
        type: z.nativeEnum(InspectionType),
        address: z.object({
          street1: z.string(),
          city: z.string(),
          state: z.string(),
          zip: z.string(),
          country: z.string()
        })
      })
    }
  }, async (req, reply) => {
    const user = (req as any).user as UserContext;
    const body = req.body as any;
    const inspection = await prisma.inspection.create({
      data: {
        tenantId: user.tenantId,
        type: body.type,
        address: body.address,
        createdByUserId: user.userId,
        status: InspectionStatus.DRAFT
      }
    });
    return inspection;
  });

  // GET /v1/inspections/:id
  app.get('/v1/inspections/:id', async (req, reply) => {
    const user = (req as any).user as UserContext;
    const { id } = req.params as { id: string };
    const inspection = await prisma.inspection.findUnique({
      where: { id, tenantId: user.tenantId },
      include: {
        rooms: {
          include: {
            components: {
              include: { issues: true }
            }
          }
        }
      }
    });
    if (!inspection) return reply.status(404).send({ error: 'Not Found' });
    return inspection;
  });
}