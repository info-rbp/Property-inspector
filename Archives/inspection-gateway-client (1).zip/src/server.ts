import { buildApp } from './app';
import { env } from './config/env';

const app = buildApp();

const start = async () => {
  try {
    await app.listen({ port: env.PORT, host: '0.0.0.0' });
    console.log(`🚀 Gateway running on port ${env.PORT}`);
  } catch (err) {
    app.log.error(err);
    throw err;
  }
};

start();